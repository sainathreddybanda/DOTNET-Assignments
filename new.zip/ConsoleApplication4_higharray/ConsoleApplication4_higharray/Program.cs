﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4_higharray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = { 12, 24, 51, 76, 45 };
            int i, temp;
            temp = a[0];
            for (i = 1; i < a.Length; i++)
            {
                if (a[i] > temp)
                {
                    temp = a[i];
                }
            }
            Console.WriteLine("highest element in array" + temp);

            Console.ReadLine();
        }
    }
}
