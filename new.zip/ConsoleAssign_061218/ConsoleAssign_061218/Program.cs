﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAssign_061218
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the order id");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the customer name");
            string name = Console.ReadLine();
            Console.WriteLine("enter the item quantity");
            int quantity = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the price of an item");
            int price = Convert.ToInt32(Console.ReadLine());
            order obj = null;
            Console.WriteLine("enter the type of order");
            string type = Console.ReadLine();
            if (type == "order")
            {
                obj = new order(id, name, quantity, price);
            }
            else if (type == "orderoverseas")
            {
                obj = new orderoverseas(id, name, quantity, price);
            }
            if (obj!=null)
            { 

         
            Console.WriteLine(obj.PorderId);
            Console.WriteLine(obj.PcustomerName);
            int Result = obj.GetOrderValue();
            Console.WriteLine(Result);
        }
            Console.ReadLine();
        }
    }
}
