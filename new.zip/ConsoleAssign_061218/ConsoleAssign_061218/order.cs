﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAssign_061218
{
    class order
    {
        private int OrderId;
        private string CustomerName;
        private int ItemQuantity;
        private int ItemPrice;

        public order(int OrderId,string CustomerName,int ItemQuantity,int ItemPrice)
        {
            this.OrderId = OrderId;
            this.CustomerName = CustomerName;
            this.ItemQuantity = ItemQuantity;
            this.ItemPrice = ItemPrice;
        }
        public int PorderId { get { return this.OrderId; } }
        public string PcustomerName { get { return this.CustomerName; } }
        public int PitemQuantity { get { return this.ItemQuantity; } }
        public int PitemPrice
        {
            get { return this.ItemPrice; }
        }
        public virtual int GetOrderValue()
        {
            return PitemPrice * PitemQuantity;
        }
            

             
       
    }
}
