﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAssign_061218
{
    class orderoverseas : order
    {
        public orderoverseas(int OrderId, string CustomerName, int ItemQuantity, int ItemPrice) : base(OrderId, CustomerName, ItemQuantity, ItemPrice)
        {

        }
        public override int GetOrderValue()
        {
            int result;
             result=(PitemPrice * PitemQuantity) * 10 / 100;
            result = result + (PitemQuantity * PitemPrice);
            return result;
        }
    }
}
