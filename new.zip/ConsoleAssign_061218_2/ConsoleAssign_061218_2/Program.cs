﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAssign_061218_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the loan id");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter customer name");
            string name = Console.ReadLine();
            Console.WriteLine("enter the emailid of customer");
            string email = Console.ReadLine();
            Console.WriteLine("enter customer mobile no");
            double number = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("enter the loan amount");
            int loanamount = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter duration");
            int duration = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the rate of intrest");
            int rate = Convert.ToInt32(Console.ReadLine());
            loan obj = null;
            Console.WriteLine("enter the type of loan");
            string type = Console.ReadLine();
            if(type=="homeloan")
            {
                obj = new homeloan(id, name, email, number, loanamount, duration, rate);
            }
            else if(type=="vehicleloan")
            {
                obj=new vehicleloan(id, name, email, number, loanamount, duration, rate);

            }
            if(obj!=null)
            {
                Console.WriteLine(obj.PloanId);
                Console.WriteLine(obj.PcustomerName);
                Console.WriteLine(obj.PcustomerEmail);
                Console.WriteLine(obj.PcustomerMobileno);
                Console.WriteLine("enter the amount");
                int amount = Convert.ToInt32(Console.ReadLine());
                int result = obj.GetPendingLoan(amount);
                int result1 = obj.PayEmi(amount);
                Console.WriteLine(" pending loan="+result);
                Console.WriteLine("amount to pay emi=" + result1);
            }
            Console.ReadLine();
        }
    }
}
