﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAssign_061218_2
{
  abstract  class loan
    {
        private int LoanId;
        private string CustomerName;
        private string CustomerEmail;
        private double CustomerMobileno;
        private int LoanAmount;
        private int Duration;
        private int Rate;
        public loan(int LoanId,string CustomerName,string CustomerEmail,double CustomerMobileno,int LoanAmount,int Duration,int Rate)
        {
            this.LoanId = LoanId;
            this.CustomerName = CustomerName;
            this.CustomerEmail = CustomerEmail;
            this.CustomerMobileno = CustomerMobileno;
            this.LoanAmount = LoanAmount;
            this.Duration = Duration;
            this.Rate = Rate;
        }
        public abstract int GetPendingLoan(int Amount);
        public abstract int PayEmi(int Amount);

        public int PloanId { get { return this.LoanId; } }
        public string PcustomerName { get { return this.CustomerName; } }
        public string PcustomerEmail { get { return this.CustomerEmail; } }
        public double PcustomerMobileno { get { return this.CustomerMobileno; } }
        public int PloanAmount { get { return this.LoanAmount; } }
        public int Prate { get { return this.Rate; } }
        
    }
}
