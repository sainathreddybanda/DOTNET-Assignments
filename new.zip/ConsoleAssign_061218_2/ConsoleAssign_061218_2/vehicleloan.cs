﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAssign_061218_2
{
    class vehicleloan:loan
    {
        public vehicleloan(int LoanId, string CustomerName, string CustomerEmail, double CustomerMobileno, int LoanAmount, int Duration, int Rate) : base(LoanId, CustomerName, CustomerEmail, CustomerMobileno, LoanAmount, Duration, Rate)
        {

        }

        public override int GetPendingLoan(int Amount)
        {
            //throw new NotImplementedException();
            int result;
            result = Amount + (PloanAmount * Prate) / 100;
            return result + 1000+PloanAmount;

        }

        public override int PayEmi(int Amount)
        {
            //throw new NotImplementedException();

            int result;
            result = Amount + (PloanAmount * Prate) / 12;
            return result+500;
        }
    }
}
