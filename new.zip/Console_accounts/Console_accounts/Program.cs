﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_accounts
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the account id");
            int AccountId = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("enter the customer name");
            string CustomerName = Console.ReadLine();
            Console.WriteLine("enter the balance in account");
            int Balance = Convert.ToInt16(Console.ReadLine());
            bool flag = true;
            account obj = new account(AccountId, CustomerName, Balance);
            while (flag == true)
            { 
                Console.WriteLine("Withdraw - 1, Deposit - 2, Checkbalance - 3, Exit - 4");
            int opt = Convert.ToInt16(Console.ReadLine());
            
                       
                switch (opt)
                {
                    case 1:
                        {
                            Console.WriteLine("enter the amount to withdraw");
                            int amnt = Convert.ToInt32(Console.ReadLine());
                            obj.WithDraw(amnt);
                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("enter the amount to deposited");
                            int amnt = Convert.ToInt32(Console.ReadLine());
                            obj.Deposit(amnt);
                            break;
                        }
                    case 3:
                        {
                           int bal=obj.GetBalance();
                            Console.WriteLine(bal);
                            break;
                        }
                    case 4:
                        {
                            flag =false;
                            break;
                        }
                }
            }
        }
    }
}