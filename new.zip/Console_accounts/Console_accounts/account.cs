﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_accounts
{
    class account
    {
        private readonly int AccountId;
        private string CustomerName;
        private int Balance;
         public account(int AccountId,string CustomerName,int Balance )
            :this(AccountId,CustomerName)
        {
           
            
            this.Balance = Balance;
            Console.WriteLine("account constructor");
        }
        public account(int AccountId, string CustomerName)
        {
            this.AccountId = AccountId;
            this.CustomerName = CustomerName;
            Console.WriteLine("account constructor");
        }
        public int GetBalance()
        {
            return Balance;  
             
        }
             public void WithDraw(int amnt)
        {
           
            
          
              
            
         
                Balance = Balance - amnt;
           
         
            
        }
        public void Deposit(int amnt)
        {
            
           
            Balance = Balance + amnt;
            
        }
    }
}
