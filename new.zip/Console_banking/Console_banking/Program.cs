﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_banking
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the account id:");
            int AccountId = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("enter name:");
            string CustomerName = Console.ReadLine();
            Console.WriteLine("enter customer address");
            string CustomerAddress = Console.ReadLine();
            Console.WriteLine("enter type of account");
            string TypeofAccount = Console.ReadLine();
            int AccountBalance = 0;
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("deposit - 1,withdrw -2,check balance - 3,exit -4");
                int opt = Convert.ToInt16(Console.ReadLine());
                switch(opt)
                {
                    case 1:
                        {
                            Console.WriteLine("enter the amount:");
                           int  a = Convert.ToInt16(Console.ReadLine());
                            if(a>=500)

                            {
                               AccountBalance = AccountBalance+a;
                                Console.WriteLine("money deposited");
                            }
                            else
                            {
                                Console.WriteLine("insufficient amount");
                            }
                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("enter amount to withdraw");
                            int c = Convert.ToInt16(Console.ReadLine());
                            if (AccountBalance < c)
                            {
                                Console.WriteLine("no sufficeint funds");
                            }
                            else
                            {
                                AccountBalance = AccountBalance - c;
                            }
                            break;

                            }
                    case 3:
                        {
                            Console.WriteLine("the balance is:" + AccountBalance);
                            break;
                        }
                    case 4:
                        {
                            flag = false;
                            break;
                        }
                        }
          
                }
            }
        }
    }

