﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_call_dill
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter no of days");
            int Days = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter per day salary");
            int Per_Day_Salary = Convert.ToInt32(Console.ReadLine());
            salary_library.Salary_class obj = new salary_library.Salary_class();


            int total = obj.GetSalary(Days, Per_Day_Salary);
            Console.WriteLine("salary :" + total);
            Console.ReadLine();
                    
        }
    }
}
