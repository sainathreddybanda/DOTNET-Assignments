﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_employee_generic
{
    class Program
    {
        static void Main(string[] args)
        {
            company c = new company(1462, "BRANDSYSTEMS");
            Console.WriteLine(c.PcompanyId + " " + c.PcompanyName);
            bool flag = true;
            while(flag)
            {
                Console.WriteLine("1-Add an employee, 2-Remove an employee, 3-search employee, 4-show employee,5-request leave, 6-exit");
                int a = Convert.ToInt32(Console.ReadLine());
                switch(a)
                {
                    case 1:
                        {
                            Console.WriteLine("enter employee name");
                            string name = Console.ReadLine();
                            Console.WriteLine("enter Employee city");
                            string city = Console.ReadLine();
                            employee obj = new employee(name, city);
                            c.AddEmployee(obj);
                            Console.WriteLine("your employeeid=" + obj.PemployeeId);
                            break;

                        }
                    case 2:
                        {
                            Console.WriteLine("enter the employee id");
                            int id = Convert.ToInt32(Console.ReadLine());
                            bool obj = c.RemoveEmployee(id);
                            if(obj!=false)
                            {
                                Console.WriteLine("employee removed");


                            }
                            else
                            {
                                Console.WriteLine("employee not found");
                            }
                            break;
                        
                        }
                    case 3:
                        {
                            Console.WriteLine("enter employee id");
                            int id = Convert.ToInt32(Console.ReadLine());
                            employee obj = c.SearchEmployee(id);
                            if(obj!=null)
                            {
                                Console.WriteLine("employee id:" + obj.PemployeeId + "employeename:" +obj.PemployeeName +"employeecity:" +obj.PemployeeCity);

                            }
                            else
                            {
                                Console.WriteLine("no employee found");
                            }
                            break;
                        }
                    case 4:
                        {
                            c.ShowEmployee();
                            break;
                        }
                    case 5:
                        {
                            Console.WriteLine("enter employee id");
                            int id = Convert.ToInt32(Console.ReadLine());
                            employee obj = c.SearchEmployee(id);
                            if(obj!=null)
                            {
                                Console.WriteLine("enter the reason for leave");
                                string reason = Console.ReadLine();
                                obj.RequestLeave(reason);
                            }
                            else
                            {
                                Console.WriteLine("not found");
                            }
                            break;
                        }
                    case 6:
                        {
                            flag = false;
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("invaid input");
                            break;

                        }
                }
            }
        }
    }
}
