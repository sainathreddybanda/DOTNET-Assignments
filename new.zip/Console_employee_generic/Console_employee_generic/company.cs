﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_employee_generic
{
    class company
    {
        private int CompanyId;
        private string CompanyName;
        private List<employee> employeelist = new List<employee>();
        public company(int CompanyId,string CompanyName)
        {
            this.CompanyId = CompanyId;
            this.CompanyName = CompanyName;
        }
        public int PcompanyId { get { return this.CompanyId; } }
        public string PcompanyName { get { return this.CompanyName; } }
        public void AddEmployee(employee name)
        {
            employeelist.Add(name);
            Console.WriteLine("employee added successfully");
        }
        public bool RemoveEmployee(int id)
        {
            foreach (employee s in this.employeelist)
            {
                if (s.PemployeeId == id)
                {
                    this.employeelist.Remove(s);
                    return true;
                }
            }
            return false;
        }
        public employee SearchEmployee(int id)
        {
            foreach (employee s in this.employeelist)
            {
                if (s.PemployeeId == id)
                {
                    return s;
                }
            }
            return null;
        }
        public void ShowEmployee()
        {
            foreach(employee s in this.employeelist)
            {
                Console.WriteLine(s.PemployeeId + " " + s.PemployeeName);
            }
        }

        
    }
}
