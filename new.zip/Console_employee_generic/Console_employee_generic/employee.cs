﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_employee_generic
{
    class employee
    {
        private int EmployeeId;
        private string EmployeeName;
        private string EmployeeCity;
        private static int count = 1000;
        public employee(string EmployeeName,string EmployeeCity)
        {
            this.EmployeeId = employee.count++;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;
        }
        public int PemployeeId { get { return this.EmployeeId; } }
        public string PemployeeName { get { return this.EmployeeName; } }
        public string PemployeeCity { get { return this.EmployeeCity; } }
        public void RequestLeave(string Reason)
        {
            Console.WriteLine("Employee id:" + this.EmployeeId + "EmployeeName:" + this.EmployeeName +"Reason:" + Reason);

        }
    }
}
