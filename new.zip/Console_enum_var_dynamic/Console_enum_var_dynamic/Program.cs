﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_enum_var_dynamic
{
    class Program
    {
        static void Main(string[] args)
        {
            var a = 100;
            var b = "abc";
            test t = new test();
            t.call(paymenttypes.Card);
            t.call(paymenttypes.NetBanking);
            t.call(paymenttypes.COD);
            Console.ReadLine();

        }
    }
}
