﻿enum paymenttypes
{
    COD,Cash,Card,NetBanking
}