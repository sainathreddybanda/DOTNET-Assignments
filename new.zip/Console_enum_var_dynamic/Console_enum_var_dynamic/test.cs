﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_enum_var_dynamic
{
    class test
    {
        public void call(paymenttypes type)
        {
            Console.WriteLine(type.ToString());
            Console.WriteLine(Convert.ToInt32(type));
            if(type==paymenttypes.Card)
            {
                Console.WriteLine("card payment");
            }
        }
    }
}
