﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_home_assignment3
{
    class Program
    {
        static void Main(string[] args)
        {
            order o = new order();
            Console.WriteLine("enter the orderid:");
            o.OrderId = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("enter the customer name:");
            o.CustomerName = Console.ReadLine();
            Console.WriteLine("enter name of the item");
            o.ItemName = Console.ReadLine();
            Console.WriteLine("enter the quantity");
            o.ItemQuantity = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("enter the cost for single item");
            o.ItemPrice = Convert.ToInt16(Console.ReadLine());
            int Amount = o.GetOrderValue();
            Console.WriteLine("the total bill is" + Amount);
            Console.ReadLine();

        }
    }
}
