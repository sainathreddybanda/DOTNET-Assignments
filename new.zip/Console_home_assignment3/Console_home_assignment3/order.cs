﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_home_assignment3
{
    class order
    {
        
  public      int OrderId;
  public      string CustomerName;
  public      string ItemName;
      public  int ItemQuantity;
       public int ItemPrice;
 public       int GetOrderValue()
        {
            return ItemQuantity * ItemPrice;
        }
        
    }
}
