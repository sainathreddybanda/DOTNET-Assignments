﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the employeeid");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter employee name");
            string name = Console.ReadLine();
            Console.WriteLine("enter employee city");
            string city = Console.ReadLine();
            Console.WriteLine("enter employee salary");
            int sal = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter employee address");
            string add = Console.ReadLine();
            Console.WriteLine("enter project details");
            string project = Console.ReadLine();
            Console.WriteLine("enter employee experince");
            int exp = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter account number");
            int accno = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter name of the bank");
            string bankname = Console.ReadLine();
            Console.WriteLine("enter age of an employee");
            int age = Convert.ToInt32(Console.ReadLine());
            employee emp = new employee(id, name, city, sal, add, project, exp, accno, bankname, age);
          



            hr obja = new hr();
            obja.GetEmployee(emp);

            manager objb = new manager();
            objb.GetEmployee(emp);

            account objc = new account();
            objc.GetEmployee(emp);

            Console.ReadLine();
            
        }
    }
}
