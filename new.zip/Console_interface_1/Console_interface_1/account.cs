﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_1
{
    class account
    {
        public void GetEmployee(iaccountemp obj)
        {
            int sal = obj.GetEmployeeSalary();
            int id = obj.GetEmployeeId();
            int accno = obj.GetEmployeeAccountNumber();
            Console.WriteLine("Account details: \n EMPLOYEESALARY=" + sal + "\n EMPLOYEEID=" + id + "\n EMPLOYEEACCOUNTNUMBER=" + accno);

        }
    }
}
