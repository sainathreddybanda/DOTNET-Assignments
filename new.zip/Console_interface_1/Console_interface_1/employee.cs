﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_1
{
    class employee:imanageremp,iaccountemp,ihremp
    {
        private int EmployeeId;
        private string EmployeeName;
        private string EmployeeCity;
        private int EmployeeSalary;
        private string EmployeeAddress;
        private string EmployeeProject;
        private int EmployeeExp;
        private int EmployeeAccountNo;
        private string EmployeeAccountBankName;
        private int EmployeeAge;
        
        public employee(int EmployeeId,string EmployeeName, string EmployeeCity, int EmployeeSalary, string EmployeeAddress, string EmployeeProject, int EmployeeExp, int EmployeeAccountNo, string EmployeeAccountBankName,int EmployeeAge)
        {
            this.EmployeeId = EmployeeId;
            this.EmployeeName = EmployeeName;
            this.EmployeeSalary = EmployeeSalary;
            this.EmployeeAddress = EmployeeAddress;
            this.EmployeeProject = EmployeeProject;
            this.EmployeeExp = EmployeeExp;
            this.EmployeeAccountNo = EmployeeAccountNo;
            this.EmployeeAccountBankName = EmployeeAccountBankName;
            this.EmployeeAge = EmployeeAge;
        }

        public int GetEmployeeId()
        {
            return this.EmployeeId;
        }

        public int GetEmployeeExp()
        {
            return this.EmployeeExp;
        }

        public string GetEmployeeProject()
        {
            return this.EmployeeProject;
        }

        public int GetEmployeeSalary()
        {
            return this.EmployeeSalary;
        }

        public int GetEmployeeAccountNumber()
        {
            return this.EmployeeAccountNo;
        }

        public string GetEmployeeAddress()
        {
            return this.EmployeeAddress;
        }
    }
}
