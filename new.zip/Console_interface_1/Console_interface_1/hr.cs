﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_1
{
    class hr
    {
        public void GetEmployee(ihremp obj)
        {
           string adres=obj.GetEmployeeAddress();
            int sal = obj.GetEmployeeSalary();
            int id = obj.GetEmployeeId();
            Console.WriteLine("HR DETAILS: \nEMPLOYEEADDRESS=" + adres  + 
                                       "\n EMPLOYEESALARY=" + sal +
                                      "  \n EMPLOYEEID=" + id);

        }
    }
}
