﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_1
{
    interface iaccountemp
    {
        int GetEmployeeSalary();
        int GetEmployeeAccountNumber();
        int GetEmployeeId();

    }
}
