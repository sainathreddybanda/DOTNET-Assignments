﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_1
{
    class manager
    {
        public void GetEmployee(imanageremp obj)
        {
            int id = obj.GetEmployeeId();
            int exp = obj.GetEmployeeExp();
            string pro = obj.GetEmployeeProject();
            Console.WriteLine("Manager Details: \n EMPLOYEEID=" + id + "\n EMPLOYEEEXPEREINCE=" + exp + "\n EMPLOYEEPROJECTDETAILS=" + pro);

        }
    }
}
