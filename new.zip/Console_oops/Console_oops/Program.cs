﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oops
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the number1");
            int n1 = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("enter the number 2");
            int n2 = Convert.ToInt16(Console.ReadLine());

            Calculator obj = new Calculator();
            obj.Number1 = n1;
            obj.Number2 = n2;

            int result = obj.sum();
            Console.WriteLine("the result is :" + result);
            int result1 = obj.subtract();
            Console.WriteLine("the difference is:" + result1);
            Console.ReadLine();
        }
    }
}
