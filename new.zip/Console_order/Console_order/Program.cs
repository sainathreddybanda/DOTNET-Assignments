﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_order
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the order id");
            int OrderId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the customer name");
            string CustomerName = Console.ReadLine();
            Console.WriteLine("enter item name");
            string ItemName = Console.ReadLine();
            Console.WriteLine("enter price of an item");
            int ItemPrice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter quantity of item");
            int ItemQuantity = Convert.ToInt32(Console.ReadLine());
            orders obj = new orders(OrderId, CustomerName, ItemName, ItemPrice, ItemQuantity);
            int Result = obj.GetOrderAmount();
            Console.WriteLine(Result);
            Console.ReadLine();
        }
    }
}
