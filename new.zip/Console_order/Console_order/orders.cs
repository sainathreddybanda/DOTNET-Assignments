﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_order
{
    class orders
    {
        private int OrderId;
        private string CustomerName;
        private string ItemName;
        private int ItemPrice;
        private int ItemQuantity;

        public  orders(int OrderId, string CustomerName, string ItemName, int ItemPrice, int ItemQuantity)
            
        {
            this.OrderId = OrderId;
            this.CustomerName = CustomerName;
            this.ItemName = ItemName;
            this.ItemPrice = ItemPrice;
            this.ItemQuantity = ItemQuantity;
            
        }
        public int GetOrderAmount()
                        {
            return ItemPrice * ItemQuantity;
        }
       
        
            
        
    }
}
