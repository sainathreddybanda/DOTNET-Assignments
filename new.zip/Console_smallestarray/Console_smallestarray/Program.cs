﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_smallestarray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = { 20, 4, 53, 42, 1 };
            int temp,loc=1;
            temp = a[0];
            for (int i = 1; i < a.Length; i++)
            {


                if (a[i] < temp)
                {
                    temp = a[i];
                    loc = i + 1;
                    Console.WriteLine("the smallest element in an array=" + temp);
                }
                






            }
            Console.ReadLine();
        }
    }

}