﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_studentcollege
{
    class Program
    {
static void Main(string[] args)
        {
            college c = new college(1001, "jntuh");
            Console.WriteLine(c.PcollegeId + " " + c.PcollegeName);
            bool flag = true;
            while(flag)
            {
                Console.WriteLine("1-add,2-find,3-remove,4-show,5-requestleave,6-exit");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch(opt)
                {
                    case 1:
                        {
                            Console.WriteLine("enter student name");
                            string studentname = Console.ReadLine();
                            Console.WriteLine("enter student city");
                            string city = Console.ReadLine();
                            student obj = new student(studentname, city);
                            c.AddStudent(obj);
                            Console.WriteLine("your studentid=" + obj.Pstudentid);
                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("enter student id");
                            int id = Convert.ToInt32(Console.ReadLine());
                            student obj = c.FindStudent(id);
                            if(obj!=null)
                            {
                                Console.WriteLine(" student details");
                                Console.WriteLine(obj.Pstudentid + " " + obj.PstudentName + " " + obj.PstudentCity);


                            }
                            else
                            {
                                Console.WriteLine("no student found");
                            }
                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("enter the student id");
                            int id = Convert.ToInt32(Console.ReadLine());
                            bool obj = c.RemoveStudent(id);
                            if(obj!=false)
                            {
                                Console.WriteLine("student removed");
                            }
                            else
                            {
                                Console.WriteLine("student doesnt exist");
                            }
                            break;
                        }
                    case 4:
                        {

                            c.ShowAll();
                            break;
                        }
                    case 5:
                        {
                            Console.WriteLine("enter student id");
                            int id = Convert.ToInt16(Console.ReadLine());
                            student obj = c.FindStudent(id);
                            if(obj!=null)
                            {
                                Console.WriteLine("enter the reason for leave");
                                string reason = Console.ReadLine();
                                obj.LeaveRequest(reason);
                            }
                            else
                            {
                                Console.WriteLine("wrong student id");
                            }
                            
                            break;
                        }
                    case 6:
                        {
                            flag =false;
                            break;

                        }
                    default:
                        {
                            Console.WriteLine("entered invalid number");
                            break;
                        }
                        

                        
                }
            }
        }
    
        
    }
}
