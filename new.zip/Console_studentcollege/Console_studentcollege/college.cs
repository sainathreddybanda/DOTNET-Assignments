﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_studentcollege
{
    class college
    {
        private int CollegeId;
        private string CollegeName;
        private List<student> studentlist = new List<student>();
        public college(int CollegeId,string CollegeName)
        {
            this.CollegeId = CollegeId;
            this.CollegeName = CollegeName;
        }
        public int PcollegeId { get { return this.CollegeId; } }

        public string PcollegeName { get { return this.CollegeName; } }
        public void AddStudent(student obj)
        {
            studentlist.Add(obj);
            Console.WriteLine("student added succesfully");
        }
        public bool RemoveStudent(int Id)
        {
            foreach(student s in this.studentlist)
            {
                if(s.Pstudentid==Id)
                {
                    this.studentlist.Remove(s);
                    return true;
                }
            }
            return false;

        }

        public student FindStudent(int Id)
        {
            foreach(student a in this.studentlist)
            {
                if(a.Pstudentid==Id)
                {
                    return a;
                }
            }
            return null;
        }
        public void ShowAll()
            {
            foreach(student s in this.studentlist)
            {
                Console.WriteLine(s.Pstudentid + " " + s.PstudentName);
            }
        }
    }
}
