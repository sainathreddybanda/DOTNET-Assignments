﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_studentcollege
{
    class student
    {
        private int StudentId;
        private string StudentName;
        private string StudentCity;
        private static int count = 1000;
        public student(string StudentName,string StudentCity)
        {
            this.StudentId = student.count++;
            this.StudentName = StudentName;
            this.StudentCity = StudentCity;

        }
        public int Pstudentid { get { return this.StudentId; } }
        public string PstudentName { get { return this.StudentName; } }
        public string PstudentCity { get { return this.StudentCity; }set { this.StudentCity = value; } }
        public void LeaveRequest(string Reason)
        {
            Console.WriteLine("leave request: studentid=" + this.StudentId + "reason=" + Reason);
        }
           
    }
}
