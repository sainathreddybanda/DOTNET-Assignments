﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_swapwithout3var
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the value ");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter another value");
            int b = Convert.ToInt32(Console.ReadLine());
            a = a + b;
            b = a - b;
            a = a - b;
            Console.WriteLine("values after swapping" + a + b);
            Console.ReadLine();
        }
    }
}
