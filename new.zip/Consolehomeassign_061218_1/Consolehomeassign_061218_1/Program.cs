﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consolehomeassign_061218_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the name of the custmer");
            string name = Console.ReadLine();
            Console.WriteLine("enter the balance in the account");
            int balance = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the type of accont");
            string type = Console.ReadLine();
            account obj = null;
            if (type == "saving")
            {
                obj = new saving(name, balance);
            }
            else if (type == "current")
            {
                obj = new current(name, balance);
            }
            if (obj != null)
            {

                Console.WriteLine(obj.PaccountId);
                Console.WriteLine(obj.PcustomerName);
                int Balance = obj.GetBalance();
                Console.WriteLine(Balance);
                Console.WriteLine("enter amount to be deposited");
                int Amount = Convert.ToInt32(Console.ReadLine());
                obj.Deposit(Amount);
                Balance = obj.GetBalance();
                Console.WriteLine(Balance);
                Console.WriteLine("enter the amount to be withdrawn");
                int Amount1 = Convert.ToInt32(Console.ReadLine());
                obj.WithDraw(Amount1);
                Balance = obj.GetBalance();
                Console.WriteLine(Balance);
            }
            Console.ReadLine();
        }
    }
}
