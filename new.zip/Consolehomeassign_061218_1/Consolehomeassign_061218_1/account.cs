﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consolehomeassign_061218_1
{
    abstract class account
    {
        private int AccountId;
        private string CustomerName;
        protected int AccountBalance;
        private static int count = 1001;
        public account(string CustomerName, int AccountBalance)
        {
            this.AccountId = account.count++;
            this.CustomerName = CustomerName;
            this.AccountBalance = AccountBalance;
            Console.WriteLine("account abstract class constructor");
        }
        public int GetBalance()
        {
            return this.AccountBalance;
        }
        public void StopPayment()
        {
            Console.WriteLine("stop payment");
        }
        public abstract void Deposit(int Amount);
        public abstract void WithDraw(int Amount);
        public int PaccountId { get { return this.AccountId; } }
        public string PcustomerName { get { return this.CustomerName; } }
        public int PaccountBalance { get { return this.AccountBalance; } }

    }
}
