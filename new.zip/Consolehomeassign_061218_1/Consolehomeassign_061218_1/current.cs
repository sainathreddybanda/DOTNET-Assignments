﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consolehomeassign_061218_1
{
    class current:account
    {
        public current(string CustomerName, int AccountBalance) : base(CustomerName, AccountBalance)
        {
            Console.WriteLine("current object constructor");
        }

        public override void Deposit(int Amount)
        {
            //throw new NotImplementedException();
            this.AccountBalance = this.AccountBalance + Amount;
        }

        public override void WithDraw(int Amount)
        {
            //throw new NotImplementedException();
            this.AccountBalance = this.AccountBalance - Amount;
        }
    }
}
