﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consolehomeassign_061218_1
{
    class saving:account
    {
        public saving(string CustomerName, int AccountBalance) : base(CustomerName, AccountBalance)
        {
            Console.WriteLine("saving object constructor");
        }

        public override void Deposit(int Amount)
        {
            // throw new NotImplementedException();
            this.AccountBalance = this.AccountBalance + Amount + 100;
        }

        public override void WithDraw(int Amount)
        {
            // throw new NotImplementedException();
            this.AccountBalance = this.AccountBalance - Amount - 20;
        }
    }
}
