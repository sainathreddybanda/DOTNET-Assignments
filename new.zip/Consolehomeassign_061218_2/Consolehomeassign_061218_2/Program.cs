﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consolehomeassign_061218_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the name of an employee");
            string name = Console.ReadLine();
            Console.WriteLine("enter the monthly salary of an employee");
            double salary = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("enter the type of an employee");
            string type = Console.ReadLine();

            employee obj = null;
            if (type == "normal")
            {
                obj = new employee(name, salary);
            }
            else if (type == "contract")
            {
                obj = new employee_contract(name, salary);
            }
            else if (type == "traine")
            {
                obj = new traine(name, salary);
            }
            if (obj != null)
            {
                Console.WriteLine(obj.PemployeeId);
                Console.WriteLine(obj.PemployeeName);
                Console.WriteLine(obj.PemployeeSalary);
                string Details = obj.GetDetails();
                Console.WriteLine(Details);
                string Work = obj.GetWork();
                Console.WriteLine(Work);
                Console.WriteLine("enter no.of days");
                int Days = Convert.ToInt32(Console.ReadLine());
                double Salary = obj.GetSalary(Days);

                Console.WriteLine(Salary);
            }

        }
    }
}
