﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consolehomeassign_061218_2
{
    class employee
    {
        private int EmployeeId;
        private string EmployeeName;
        private double MonthlySalary;
        private static int count = 1000;
        public employee(string EmployeeName, double MonthlySalary)
        {
            this.EmployeeId = ++employee.count;
            this.EmployeeName = EmployeeName;
            this.MonthlySalary = MonthlySalary;
        }
        public int PemployeeId { get { return this.EmployeeId; } }
        public string PemployeeName { get { return this.EmployeeName; } }
        public double PemployeeSalary { get { return this.MonthlySalary; } }
        public string GetDetails()
        {
            return this.EmployeeId + " " + EmployeeName;
        }
        public string GetWork()
        {
            return "dotnet developer";
        }
        public virtual double GetSalary(int Days)
        {
            int Bonus = 2000;
            int TDS = 800;
            double Total = (this.MonthlySalary / 30) * Days + Bonus - TDS;
            return Total;
        }

    }
}
