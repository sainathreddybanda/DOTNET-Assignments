﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consolehomeassign_061218_2
{
    class employee_contract:employee
    {
        public employee_contract(string EmployeeName, double MonthlySalary) : base(EmployeeName, MonthlySalary)
        {

        }
        public override double GetSalary(int Days)
        {
            double Total = (this.PemployeeSalary / 30) * Days;
            return Total;
        }
    }
}
