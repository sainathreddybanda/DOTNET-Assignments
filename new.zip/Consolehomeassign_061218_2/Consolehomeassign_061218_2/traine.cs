﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consolehomeassign_061218_2
{
    class traine:employee
    {
        public traine(string Employeename, double MonthlySalary) : base(Employeename, MonthlySalary)
        {

        }
        public override double GetSalary(int Days)
        {
            double Total = (this.PemployeeSalary / 30) * Days - 2000;
            return Total;
        }
    }
}
