create database emp_db
use emp_db
create table tbl_employees
(
employeeid int,
employeefname varchar(100),
employeelname varchar(100),
employeecity varchar(100),
employeedoj datetime,
employeesalary int,
employeestatus varchar(100)
)
alter table tbl_employees add employeedept varchar(100),employeedob datetime
insert tbl_employees values(1009,'banala','sneha','chennai','02/08/2018',30000,'active','Hr','02/06/1996')
select * from tbl_employees
select *from tbl_employees where employeecity='chennai'
select * from tbl_employees where employeesalary between 25000 and 50000
select employeeid,employeecity ,employeelname+employeefname as 'employeefullname' from tbl_employees
select * from tbl_employees order by len(employeefname) asc
select sum(employeesalary) from tbl_employees
select count(*) from tbl_employees
select * from tbl_employees where datename(mm,employeedoj)in('january','december')
select * from tbl_employees where datediff(yy,employeedoj,getdate()) >5
select employeedept ,count(*) from tbl_employees group by employeedept
select employeecity,count(*) from tbl_employees group by employeecity
update  tbl_employees set employeecity='pune' where employeecity='chennai' 
select employeedept,sum(employeesalary) from tbl_employees group by employeedept having sum(employeesalary)>30000
update tbl_employees set employeestatus='active' where employeesalary=20000
select * from tbl_employees where datename(mm,employeedoj)=datename(mm,getdate())
create table tbl_employeeprojects
(
employeeid int,
employeeprojectname varchar(100),
duration int,
skillset varchar(100)
)
insert tbl_employeeprojects values(1003,'launcher',300,' core java')
select * from tbl_employeeprojects
select employeeid,count(*) from tbl_employeeprojects group by employeeid