create table tbl_accounts
(
accountid int identity(1000,1),
customername varchar(100),
accountbalance int
)
insert tbl_accounts values('balu',3000)
select * from tbl_accounts
select @@IDENTITY