create database db_foodorder
use db_foodorder
create table tbl_restaurants
(
restaurantid int identity(100,1) primary key,
restaurantname varchar(100),
restaurantaddress varchar(100),
restaurantcity varchar(100),
contactno varchar(20)
)
insert tbl_restaurants values('almas','hsr','blr','9843673079')
select * from tbl_restaurants

create table tbl_rmenuitems
(
menuid int identity(50,5) primary key,
restaurantid int foreign key references  tbl_restaurants,
menuname varchar(100),
menutype varchar(100),
menucategory varchar(100),
menuprice int,
menudesc varchar(100)
)
insert tbl_rmenuitems values(102,'bar','large ',null,280,'ice cubes')
select * from tbl_rmenuitems
create table tbl_customers
(
customerid varchar(100) primary key,
customername varchar(100),
customercity varchar(100),
customerdob datetime,
customergender varchar(100),
customerpassword varchar(100)
)
insert tbl_customers values('sneharoa@gmail','sneha','blr','06/12/1997','female','chai')
select * from tbl_customers
create table tbl_orders
(
orderid int identity(1245,1) primary key,
customerid varchar(100) foreign key references tbl_customers,
orderdate datetime,
deliveryaddress varchar(100),
orderstatus varchar(100)
)
insert tbl_orders values('sai@gmail',getdate(),'btm','preparing')
select * from tbl_orders
create table tbl_ordermenus
(
orderid int foreign key references tbl_orders,
menuid int foreign key references tbl_rmenuitems,
menuqty int,
menuprice int,
primary key(orderid,menuid)
)
insert tbl_ordermenus values(1248,65,4,100)
select * from tbl_ordermenus

select * from tbl_restaurants where restaurantcity='hyd'

select tbl_restaurants.restaurantid,tbl_restaurants.restaurantname,tbl_rmenuitems.menuid,
tbl_rmenuitems.menuname,tbl_rmenuitems.menuprice from tbl_restaurants join tbl_rmenuitems
on tbl_restaurants.restaurantid=tbl_rmenuitems.restaurantid

select tbl_restaurants.restaurantid,tbl_restaurants.restaurantname,tbl_rmenuitems.menuid,
tbl_rmenuitems.menuname,tbl_rmenuitems.menuprice from tbl_restaurants join tbl_rmenuitems
on tbl_restaurants.restaurantid=tbl_rmenuitems.restaurantid where tbl_restaurants.restaurantcity='hyd'

select * from tbl_orders where customerid='sai@gmail'

select tbl_orders.orderid,tbl_orders.customerid,tbl_orders.orderdate,tbl_ordermenus.menuid,
tbl_ordermenus.menuqty,tbl_ordermenus.menuprice from tbl_orders join tbl_ordermenus on
tbl_orders.orderid=tbl_ordermenus.orderid

select top 5 * from tbl_orders where customerid='sai@gmail' order by orderdate desc

select * from tbl_ordermenus order by menuprice asc

select restaurantcity,count(*) from tbl_restaurants group by restaurantcity

select * from tbl_customers where customerid not in
(select customerid from tbl_orders)

select  top 1* from tbl_ordermenus  order by menuprice desc
 
select top 2 * from tbl_ordermenus  order by menuprice desc 