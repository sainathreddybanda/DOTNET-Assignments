﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_orders
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

     

        private void btn_login_Click(object sender, EventArgs e)
        {
if(txt_login.Text==string.Empty)
            {
                MessageBox.Show("enter logi id");
            }
else if(txt_password.Text==string.Empty)
            {
                MessageBox.Show("enter password");
            }
else
            {
                int id = Convert.ToInt32(txt_login.Text);
                string password = txt_password.Text;
                if(id==101 && password=="sai")
                {
                    MessageBox.Show("valid customer");
                    frm_neworder obj1 = new frm_neworder();
                    obj1.Show();
                }
                else
                {
                    MessageBox.Show("invalid customer");
                }
                       
            }
        }

        private void btn_newcustomer_Click(object sender, EventArgs e)
        {
            frm_newuser obj = new frm_newuser();
            obj.Show();
        }
    }
}
