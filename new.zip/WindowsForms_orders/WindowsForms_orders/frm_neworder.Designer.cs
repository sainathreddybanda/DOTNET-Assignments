﻿namespace WindowsForms_orders
{
    partial class frm_neworder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_itemname = new System.Windows.Forms.Label();
            this.lbl_itemprice = new System.Windows.Forms.Label();
            this.lbl_itemquantity = new System.Windows.Forms.Label();
            this.txt_itemname = new System.Windows.Forms.TextBox();
            this.txt_itemprice = new System.Windows.Forms.TextBox();
            this.txt_itemquantity = new System.Windows.Forms.TextBox();
            this.btn_neworder = new System.Windows.Forms.Button();
            this.btn_close = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_itemname
            // 
            this.lbl_itemname.AutoSize = true;
            this.lbl_itemname.Location = new System.Drawing.Point(44, 26);
            this.lbl_itemname.Name = "lbl_itemname";
            this.lbl_itemname.Size = new System.Drawing.Size(67, 13);
            this.lbl_itemname.TabIndex = 0;
            this.lbl_itemname.Text = "ITEM NAME";
            // 
            // lbl_itemprice
            // 
            this.lbl_itemprice.AutoSize = true;
            this.lbl_itemprice.Location = new System.Drawing.Point(47, 98);
            this.lbl_itemprice.Name = "lbl_itemprice";
            this.lbl_itemprice.Size = new System.Drawing.Size(68, 13);
            this.lbl_itemprice.TabIndex = 1;
            this.lbl_itemprice.Text = "ITEM PRICE";
            // 
            // lbl_itemquantity
            // 
            this.lbl_itemquantity.AutoSize = true;
            this.lbl_itemquantity.Location = new System.Drawing.Point(47, 148);
            this.lbl_itemquantity.Name = "lbl_itemquantity";
            this.lbl_itemquantity.Size = new System.Drawing.Size(91, 13);
            this.lbl_itemquantity.TabIndex = 2;
            this.lbl_itemquantity.Text = "ITEM QUANTITY";
            // 
            // txt_itemname
            // 
            this.txt_itemname.Location = new System.Drawing.Point(152, 18);
            this.txt_itemname.Name = "txt_itemname";
            this.txt_itemname.Size = new System.Drawing.Size(100, 20);
            this.txt_itemname.TabIndex = 3;
            // 
            // txt_itemprice
            // 
            this.txt_itemprice.Location = new System.Drawing.Point(152, 98);
            this.txt_itemprice.Name = "txt_itemprice";
            this.txt_itemprice.Size = new System.Drawing.Size(100, 20);
            this.txt_itemprice.TabIndex = 4;
            // 
            // txt_itemquantity
            // 
            this.txt_itemquantity.Location = new System.Drawing.Point(152, 148);
            this.txt_itemquantity.Name = "txt_itemquantity";
            this.txt_itemquantity.Size = new System.Drawing.Size(100, 20);
            this.txt_itemquantity.TabIndex = 5;
            // 
            // btn_neworder
            // 
            this.btn_neworder.Location = new System.Drawing.Point(26, 250);
            this.btn_neworder.Name = "btn_neworder";
            this.btn_neworder.Size = new System.Drawing.Size(136, 23);
            this.btn_neworder.TabIndex = 6;
            this.btn_neworder.Text = "NEW ORDER";
            this.btn_neworder.UseVisualStyleBackColor = true;
            this.btn_neworder.Click += new System.EventHandler(this.btn_neworder_Click);
            // 
            // btn_close
            // 
            this.btn_close.Location = new System.Drawing.Point(343, 249);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(75, 23);
            this.btn_close.TabIndex = 7;
            this.btn_close.Text = "CLOSE";
            this.btn_close.UseVisualStyleBackColor = true;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // frm_neworder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(577, 311);
            this.Controls.Add(this.btn_close);
            this.Controls.Add(this.btn_neworder);
            this.Controls.Add(this.txt_itemquantity);
            this.Controls.Add(this.txt_itemprice);
            this.Controls.Add(this.txt_itemname);
            this.Controls.Add(this.lbl_itemquantity);
            this.Controls.Add(this.lbl_itemprice);
            this.Controls.Add(this.lbl_itemname);
            this.Name = "frm_neworder";
            this.Text = "frm_neworder";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_itemname;
        private System.Windows.Forms.Label lbl_itemprice;
        private System.Windows.Forms.Label lbl_itemquantity;
        private System.Windows.Forms.TextBox txt_itemname;
        private System.Windows.Forms.TextBox txt_itemprice;
        private System.Windows.Forms.TextBox txt_itemquantity;
        private System.Windows.Forms.Button btn_neworder;
        private System.Windows.Forms.Button btn_close;
    }
}