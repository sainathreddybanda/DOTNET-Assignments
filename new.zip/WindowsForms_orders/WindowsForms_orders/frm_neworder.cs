﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_orders
{
    public partial class frm_neworder : Form
    {
        public frm_neworder()
        {
            InitializeComponent();
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_neworder_Click(object sender, EventArgs e)
        {
            if(txt_itemname.Text==string.Empty)
            {
                MessageBox.Show("enter item name");
            }
           else if (txt_itemprice.Text==string.Empty)
            {
                MessageBox.Show("enter price of an item");
            }
          else  if (txt_itemquantity.Text==string.Empty)

            {
                MessageBox.Show("enter the quantity");
            }
            else
            {
                string itemname = txt_itemname.Text;
                int price = Convert.ToInt32(txt_itemprice.Text);
                int quantity = Convert.ToInt32(txt_itemquantity.Text);

                order o = new WindowsForms_orders.order(itemname, price, quantity);
                int totall=o.GetOrder();
                MessageBox.Show(" result"+totall);
            }
                   
        }
    }
}
