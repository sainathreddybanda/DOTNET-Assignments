﻿namespace WindowsForms_orders
{
    partial class frm_newuser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_email = new System.Windows.Forms.Label();
            this.lbl_name = new System.Windows.Forms.Label();
            this.lbl_city = new System.Windows.Forms.Label();
            this.lbl_gender = new System.Windows.Forms.Label();
            this.cmb_customercity = new System.Windows.Forms.ComboBox();
            this.rdbtb_male = new System.Windows.Forms.RadioButton();
            this.rdbtn_female = new System.Windows.Forms.RadioButton();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.btn_login = new System.Windows.Forms.Button();
            this.btn_newuser = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_email
            // 
            this.lbl_email.AutoSize = true;
            this.lbl_email.Location = new System.Drawing.Point(31, 29);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(103, 13);
            this.lbl_email.TabIndex = 0;
            this.lbl_email.Text = "CUSTOMER EMAIL";
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Location = new System.Drawing.Point(31, 72);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(102, 13);
            this.lbl_name.TabIndex = 1;
            this.lbl_name.Text = "CUSTOMER NAME";
            // 
            // lbl_city
            // 
            this.lbl_city.AutoSize = true;
            this.lbl_city.Location = new System.Drawing.Point(31, 126);
            this.lbl_city.Name = "lbl_city";
            this.lbl_city.Size = new System.Drawing.Size(95, 13);
            this.lbl_city.TabIndex = 2;
            this.lbl_city.Text = "CUSTOMER CITY";
            // 
            // lbl_gender
            // 
            this.lbl_gender.AutoSize = true;
            this.lbl_gender.Location = new System.Drawing.Point(34, 171);
            this.lbl_gender.Name = "lbl_gender";
            this.lbl_gender.Size = new System.Drawing.Size(117, 13);
            this.lbl_gender.TabIndex = 3;
            this.lbl_gender.Text = "CUSTOMER GENDER";
            // 
            // cmb_customercity
            // 
            this.cmb_customercity.FormattingEnabled = true;
            this.cmb_customercity.Location = new System.Drawing.Point(281, 105);
            this.cmb_customercity.Name = "cmb_customercity";
            this.cmb_customercity.Size = new System.Drawing.Size(121, 21);
            this.cmb_customercity.TabIndex = 4;
            // 
            // rdbtb_male
            // 
            this.rdbtb_male.AutoSize = true;
            this.rdbtb_male.Location = new System.Drawing.Point(224, 166);
            this.rdbtb_male.Name = "rdbtb_male";
            this.rdbtb_male.Size = new System.Drawing.Size(54, 17);
            this.rdbtb_male.TabIndex = 5;
            this.rdbtb_male.TabStop = true;
            this.rdbtb_male.Text = "MALE";
            this.rdbtb_male.UseVisualStyleBackColor = true;
            // 
            // rdbtn_female
            // 
            this.rdbtn_female.AutoSize = true;
            this.rdbtn_female.Location = new System.Drawing.Point(358, 171);
            this.rdbtn_female.Name = "rdbtn_female";
            this.rdbtn_female.Size = new System.Drawing.Size(67, 17);
            this.rdbtn_female.TabIndex = 6;
            this.rdbtn_female.TabStop = true;
            this.rdbtn_female.Text = "FEMALE";
            this.rdbtn_female.UseVisualStyleBackColor = true;
            // 
            // txt_email
            // 
            this.txt_email.Location = new System.Drawing.Point(281, 29);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(100, 20);
            this.txt_email.TabIndex = 7;
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(281, 65);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(100, 20);
            this.txt_name.TabIndex = 8;
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(50, 226);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(75, 23);
            this.btn_login.TabIndex = 9;
            this.btn_login.Text = "LOGIN";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // btn_newuser
            // 
            this.btn_newuser.Location = new System.Drawing.Point(305, 226);
            this.btn_newuser.Name = "btn_newuser";
            this.btn_newuser.Size = new System.Drawing.Size(75, 23);
            this.btn_newuser.TabIndex = 10;
            this.btn_newuser.Text = "NEW USER";
            this.btn_newuser.UseVisualStyleBackColor = true;
            this.btn_newuser.Click += new System.EventHandler(this.btn_newuser_Click);
            // 
            // frm_newuser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(571, 261);
            this.Controls.Add(this.btn_newuser);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.txt_email);
            this.Controls.Add(this.rdbtn_female);
            this.Controls.Add(this.rdbtb_male);
            this.Controls.Add(this.cmb_customercity);
            this.Controls.Add(this.lbl_gender);
            this.Controls.Add(this.lbl_city);
            this.Controls.Add(this.lbl_name);
            this.Controls.Add(this.lbl_email);
            this.Name = "frm_newuser";
            this.Text = "frm_newuser";
            this.Load += new System.EventHandler(this.frm_newuser_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_email;
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.Label lbl_city;
        private System.Windows.Forms.Label lbl_gender;
        private System.Windows.Forms.ComboBox cmb_customercity;
        private System.Windows.Forms.RadioButton rdbtb_male;
        private System.Windows.Forms.RadioButton rdbtn_female;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button btn_newuser;
    }
}