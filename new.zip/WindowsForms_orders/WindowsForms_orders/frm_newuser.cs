﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_orders
{
    public partial class frm_newuser : Form
    {
        public frm_newuser()
        {
            InitializeComponent();
        }

        private void btn_newuser_Click(object sender, EventArgs e)
        {
            if(txt_email.Text==string.Empty)
            {
                MessageBox.Show("enter email");
            }
            else if(txt_name.Text==string.Empty)
            {
                MessageBox.Show("enter name of customer");
            }
            else if(cmb_customercity.Text==string.Empty)
            {
                MessageBox.Show("enter city of customer");
            }
            else if(rdbtb_male.Checked==false && rdbtn_female.Checked==false)
            {
                MessageBox.Show("select the any option in gender");
            }
            else
            {
                string email = txt_email.Text;
                string name = txt_name.Text;
                string city = cmb_customercity.Text;
                string customergender= string.Empty;
                if(rdbtb_male.Checked)
                {
                    customergender = "male";
                }
                else
                {
                    customergender = "female";
                }
                MessageBox.Show("customer added succesfully");
            }
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            Form1 obj = new Form1();
            obj.Show();
        }

        private void frm_newuser_Load(object sender, EventArgs e)
        {
            cmb_customercity.Items.Add("HYD");
            cmb_customercity.Items.Add("BLR");
            cmb_customercity.Items.Add("DLH");
        }
    }
}
