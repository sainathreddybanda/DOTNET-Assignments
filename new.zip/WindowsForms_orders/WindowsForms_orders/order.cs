﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForms_orders
{
    class order
    {
        private int OrderId;
        private string ItemName;
        private int ItemPrice;
        private int ItemQuantity;
        private static int count = 1001;
        public order(string ItemName,int ItemPrice,int ItemQuantity)
        {
            this.OrderId = order.count++;
            this.ItemName = ItemName;
            this.ItemPrice = ItemPrice;
            this.ItemQuantity = ItemQuantity;
        }
       public int PorderId { get { return this.OrderId; } }
        public string PitemName { get { return this.ItemName; } }
        public int PitemPrice { get { return this.ItemPrice; } }
        public int PitemQuantity { get { return this.ItemQuantity; } }
        public int GetOrder()
        {

            return this.PitemPrice * this.PitemQuantity;
        }
    }
}
