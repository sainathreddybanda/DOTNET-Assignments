﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_controls
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if(txt_loginid.Text==string.Empty)
            {
                MessageBox.Show("enter login id");
            }
            else if(txt_password.Text==string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else
            {
                int loginid = Convert.ToInt32(txt_loginid.Text);
                string password = txt_password.Text;
                if(loginid==1001 && password=="pass@123")
                {
                    MessageBox.Show("valid user");
                    frm_home obj = new frm_home();
                    obj.Show();
                }
                else
                {
                    MessageBox.Show("invalid user");
                }
            }
                   
        }

        private void btn_newuser_Click(object sender, EventArgs e)
        {
            frm_newuser obj = new frm_newuser();
            obj.Show();

        }
    }
}
