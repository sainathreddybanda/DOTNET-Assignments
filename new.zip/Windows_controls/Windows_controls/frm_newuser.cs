﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_controls
{
    public partial class frm_newuser : Form
    {
        public frm_newuser()
        {
            InitializeComponent();
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_newuser_Click(object sender, EventArgs e)
        {
            if(txt_loginid.Text==string.Empty)
            {
                MessageBox.Show("enter loginId");
            }
            else if(txt_password.Text==String.Empty)
            {
                MessageBox.Show("enter password");
            }
            else if(txt_customername.Text==string.Empty)
            {
                MessageBox.Show("enter customer name");
            }
            else if(cmb_city.Text==string.Empty)
            {
                MessageBox.Show("select city");
            }
            else if(rdbtn_male.Checked==false && rdbtn_female.Checked==false)
            {
                MessageBox.Show("click on the option");
            }
            else
            {
                int loginid = Convert.ToInt32(txt_loginid.Text);
                string password = txt_password.Text;
                string customername = txt_customername.Text;
                string customercity = cmb_city.Text;
                string customergender = string.Empty;
                if(rdbtn_male.Checked)
                {
                    customergender = "male";
                }
                else
                {
                    customergender = "female";
                }
                MessageBox.Show("customer created");
            }
        }

        private void frm_newuser_Load(object sender, EventArgs e)
        {
            cmb_city.Items.Add("BGL");
            cmb_city.Items.Add("HYD");
            cmb_city.Items.Add("PUNE");
            cmb_city.Items.Add("CHENNAI");
        }
    }
}
