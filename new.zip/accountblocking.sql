create database db_bank_blocking
use db_bank_blocking

create table tbl_cust
(
customerid int,
cpassword varchar(100),
customername varchar(100),
passwordcount int,
cstatus varchar(100),
wrongpasswordattemptdate datetime
)
select * from tbl_cust
insert tbl_cust values(1021,'saireddy','sainathreddy',0,'active',null)
update tbl_cust set passwordcount=0,cstatus='active'
 
alter procedure proc_block(@cid int,@cpassword varchar(100))
as
begin
declare @custpass varchar(100);
declare @passcount int;
select @custpass=cpassword,@passcount=passwordcount from tbl_cust where @cid=customerid
if( @custpass!=@cpassword )
begin
update tbl_cust set passwordcount=passwordcount+1,wrongpasswordattemptdate=getdate()
 where @cid=customerid
 update tbl_cust set passwordcount=1 where datediff(dd,wrongpasswordattemptdate,getdate())!=0
if(@passcount=3)
begin
update tbl_cust set cstatus='blocked' where @cid=customerid
return -1
end
return 0
end
else
begin
return 1
end
end

exec proc_block 1001,'sai'

select * from tbl_cust
