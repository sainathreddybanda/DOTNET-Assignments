﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Console_linq
{
    class Program
    {
        static void Main(string[] args)
        {
            List<customer> custlist = new List<customer>();
            custlist.Add
                (new customer { customerid = 101, customername = "sai", customercity = "hyd" });
            custlist.Add
               (new customer { customerid = 102, customername = "saiteja", customercity = "hyd" });
            custlist.Add
               (new customer { customerid = 103, customername = "saikiran", customercity = "hyd" });
            custlist.Add
               (new customer { customerid = 123, customername = "balu", customercity = "bgl" });
            custlist.Add
               (new customer { customerid = 131, customername = "yash", customercity = "bgl" });



            List<order> ordlist = new List<order>();
            ordlist.Add
                (new order { orderid = 1, itename = "fish", itemprice = 200, itemqty = 2, customerid = 102 });
            ordlist.Add
                 (new order { orderid = 2, itename = "chickrn dry", itemprice = 150, itemqty = 5, customerid = 123 });

            ordlist.Add
                           (new order { orderid = 3, itename = "chicken tikka", itemprice = 220, itemqty = 1, customerid = 131 });

            ordlist.Add
                           (new order { orderid = 4, itename = "fish fry", itemprice = 250, itemqty = 2, customerid = 102 });


            //lambda expression
            /*var data = custlist.Where(c => c.customercity == "hyd");
            foreach(var d in data)
            {
                Console.WriteLine(d.customerid + " " + d.customername + " " + d.customercity);
            }

            var data = custlist.Where(c => c.customercity == "hyd")
                .OrderByDescending(o => o.customerid).ThenByDescending(n => n.customername);

            foreach (var d in data)
            {
                Console.WriteLine(d.customerid + " " + d.customername + " " + d.customercity);
            }

            var data = custlist.Where(c => c.customercity == "hyd")
                .Select(s => new customerdetails
                {
                    customerid = s.customerid,
                    customername = s.customername
                });
            foreach (var d in data)
            {
                Console.WriteLine(d.customerid + " " + d.customername );
            }


            var count = custlist.Count(c => c.customercity == "hyd");
            Console.WriteLine(count);

            var status = custlist.Exists(c => c.customerid == 101);
            Console.WriteLine(status);

            var obj = custlist.FirstOrDefault(c => c.customerid == 1010);
            if(obj!=null)
            {
                Console.WriteLine(obj.customerid + " " + obj.customername + " " + obj.customercity);

            }
            else
            {
                Console.WriteLine("customer not found");
            }


            var joindata = custlist.Join(ordlist, c => c.customerid,
                o => o.customerid, (c, o) => new customerorder
                {
                    cid = c.customerid,
                    cname = c.customername,
                    oid = o.orderid,
                    iname = o.itename,
                    iprice = o.itemprice,
                    iqty = o.itemqty,
                    oamt = o.itemqty * o.itemprice
                });

            foreach(var d in joindata)
            {
                Console.WriteLine(d.cid + " " + d.cname + " " + d.oid + " " + d.iname + " " + d.iprice + " " + d.iqty + " " + d.oamt);
            }

            var gb = ordlist.GroupBy(g => g.customerid).Select(s => new ordergroup
            {
                customerid = s.Key,
                nooforders = s.Count(),
                ordersum = s.Sum(ss => ss.itemprice * ss.itemqty)
            });

            foreach(var g in gb)
            {
                Console.WriteLine(g.customerid + " " + g.nooforders + " " + g.ordersum);
            }*/

                                    
            
          //linq queries
          /*  var data = (from s in custlist
                        where s.customercity == "hyd"
                        select s).ToList();

            foreach(var d in data)
            {
                Console.WriteLine(d.customerid + " " + d.customername + " " + d.customercity);

            }
          var data = (from c in custlist
                      where c.customercity == "bgl"
                      select new customerdetails { customerid = c.customerid, customername = c.customername }).ToList();

          foreach(var d in data)
          {
              Console.WriteLine(d.customerid + " " + d.customername);
          }
          var data = (from c in custlist
                      where c.customercity=="hyd"
                      orderby c.customerid 
                      descending select c).ToList();
          foreach(var d in data)
          {
              Console.WriteLine(d.customerid + " " + d.customername + " " + d.customercity);
          }

          var data = (from c in custlist
                      where c.customercity == "hyd"
                      select c).Count();
          Console.WriteLine("total employees " + data);

          var obj = (from c in custlist
                     where c.customercity == "hydl"
                     select c).FirstOrDefault();
          if(obj!=null)
          {
              Console.WriteLine(obj.customerid + " " + obj.customername + " " + obj.customercity);

          }
          else
          {
              Console.WriteLine("customer not found");
          }


          var joindata = (from c in custlist
                          join o in ordlist
      on c.customerid equals o.customerid
                          select new customerorder
                          {
                              cid = c.customerid,
                              cname = c.customername,
                              oid = o.orderid,
                              iname = o.itename,
                              iprice = o.itemprice,
                              iqty = o.itemqty,oamt=o.itemqty*o.itemprice
                          }).ToList();

          foreach(var j in joindata)
          {
              Console.WriteLine(j.cid + " " + j.cname + " " + j.oid + " " + j.iname + " " + j.iprice +
                  " "+j.iqty+" "+ j.oamt);
          }

          XDocument xml = XDocument.Load(@"c:\users\kondu\documents\visual studio 2015\Console_linq\Console_linq\customersdata.xml");
          var data = (from x in xml.Descendants("customer")
                      select new customer
                      {
                          customerid = Convert.ToInt32(x.Element("customerid").Value),
                          customername = x.Element("customername").Value,
                          customercity = x.Element("customercity").Value
                      }).ToList();


          foreach(var d in data)
          {
              Console.WriteLine(d.customerid + " " + d.customername + " " + d.customercity);
          }*/







          Console.ReadLine();



        }
    }
}
