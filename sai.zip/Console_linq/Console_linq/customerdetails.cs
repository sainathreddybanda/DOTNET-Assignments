﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_linq
{
    class customerdetails
    {
        public int customerid { get; set; }
        public string customername { get; set; }
    }
}
