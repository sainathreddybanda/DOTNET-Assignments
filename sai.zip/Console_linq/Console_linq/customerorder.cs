﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_linq
{
    class customerorder
    {
        public int cid { get; set; }
        public string cname { get; set; }
        public int oid { get; set; }
        public string iname { get; set; }
        public int iqty { get; set; }
        public int iprice { get; set; }
        public int oamt { get; set; }




    }
}
