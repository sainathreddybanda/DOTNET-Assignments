﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_linq
{
    class order
    {
        public int orderid { get; set; }
        public string itename { get; set; }
        public int itemqty { get; set; }
        public int itemprice { get; set; }
        public int customerid { get; set; }
    }
}
