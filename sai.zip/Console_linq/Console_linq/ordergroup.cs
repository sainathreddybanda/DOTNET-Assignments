﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_linq
{
    class ordergroup
    {
        public int customerid { get; set; }
        public int ordersum { get; set; }
        public int nooforders { get; set; }

    }
}
