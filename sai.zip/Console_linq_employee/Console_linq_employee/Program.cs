﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_linq_employee
{
    class Program
    {
        static void Main(string[] args)
        {
            List<employee> emplist = new List<employee>();
            emplist.Add
                (new employee { employeeid = 502, employeename = "sai", employeesalary = 25000,
                    employeeexp = 4, employeecity = "hyd" });
            emplist.Add
               (new employee
               {
                   employeeid = 501,
                   employeename = "saiteja",
                   employeesalary = 52000,
                   employeeexp = 14,
                   employeecity = "hyd"
               });
            emplist.Add
               (new employee
               {
                   employeeid = 505,
                   employeename = "chunchu",
                   employeesalary = 30000,
                   employeeexp = 6,
                   employeecity = "blr"
               });
            emplist.Add
               (new employee
               {
                   employeeid = 504,
                   employeename = "yash",
                   employeesalary = 25000,
                   employeeexp = 2,
                   employeecity = "blr"
               });
            emplist.Add
               (new employee
               {
                   employeeid = 555,
                   employeename = "shivaa",
                   employeesalary = 80000,
                   employeeexp = 4,
                   employeecity = "hyd"
               });
            List<leaves> leavelist = new List<leaves>();
            leavelist.Add
                (new leaves { leaveid = 101, leavereason = "sick", leavetype = "casual", empid = 501 });
            leavelist.Add
               (new leaves { leaveid = 102, leavereason = "festival", leavetype = "occational", empid = 502 });
            leavelist.Add
               (new leaves { leaveid = 103, leavereason = "sick", leavetype = "medical", empid = 504 });
            leavelist.Add
               (new leaves { leaveid = 104, leavereason = "marriage", leavetype = "casual", empid = 555 });


            /*  var data = (from e in emplist
                          where e.employeeexp > 5
                          select e).Count();

              Console.WriteLine("the number of employees having more than 5 years experience are:" + data);
              var sal = (from e in emplist
                         where e.employeesalary > 50000
                         select e).ToList();
             foreach(var d in sal)
              {
                  Console.WriteLine(d.employeeid + " " + d.employeename + " " + d.employeesalary + " "
                      + d.employeeexp + " " + d.employeecity);
              }
              var bang = (from e in emplist
                          where e.employeecity == "blr"
                          select e).ToList();
              foreach( var d in bang)
              {
                  Console.WriteLine(d.employeeid + " " + d.employeename + " " + d.employeesalary + " "
                    + d.employeeexp + " " + d.employeecity);
              }


              var empdetails = (from e in emplist
                                where e.employeename.StartsWith("a")
                              select new  employeedetails{ empid=e.employeeid,
                  empname=e.employeename,empexp=e.employeeexp }).ToList();


            List<leaves> leavelist = new List<leaves>();
            leavelist.Add
                (new leaves { leaveid = 101, leavereason = "sick", leavetype = "casual", empid = 501 });
            leavelist.Add
               (new leaves { leaveid = 102, leavereason = "festival", leavetype = "occational", empid = 502 });
            leavelist.Add
               (new leaves { leaveid = 103, leavereason = "sick", leavetype = "medical", empid = 504 });
            leavelist.Add
               (new leaves { leaveid = 104, leavereason = "marriage", leavetype = "casual", empid = 555 });

            var join = (from e in emplist
                        join l in leavelist
      on e.employeeid equals l.empid
                        select new employeeleave
                        {
                            eid = e.employeeid,
                            ename = e.employeename,
                            lid = l.leaveid,
                            ltype = l.leavetype,
                            lreason = l.leavereason
                        }).ToList();
                       

            foreach(var d in join)
            {
                Console.WriteLine(d.eid + " " + d.ename + " " + d.lid + " "
                                  + d.ltype + " " + d.lreason);
            }*/


            var data = emplist.Count(c => c.employeeexp > 5);
                        Console.WriteLine(data);

            var sal = emplist.Where(c => c.employeesalary > 50000);
            foreach (var d in sal)
            {
                Console.WriteLine(d.employeeid + " " + d.employeename + " " + d.employeesalary + " "
                    + d.employeeexp + " " + d.employeecity);
            }

            var city = emplist.Where(c => c.employeecity == "blr");
            foreach(var d in city)
            {
                Console.WriteLine(d.employeeid + " " + d.employeename + " " + d.employeesalary + " "
                    + d.employeeexp + " " + d.employeecity);
            }



            var empdetails = emplist.Where(c => c.employeename.StartsWith("s"))
              .Select(s => new employeedetails
              {
                  empid = s.employeeid,
                  empname = s.employeename,
                  empexp = s.employeeexp
              });
            foreach(var d in empdetails)
            {
                Console.WriteLine(d.empid+" "+d.empname+" "+d.empexp);
            }


            var join = emplist.Join(leavelist, c => c.employeeid, l => l.empid, (c, l) => new employeeleave
            {
                eid = c.employeeid,
                ename = c.employeename,
                lid = l.leaveid,
                ltype = l.leavetype,
                lreason = l.leavereason
            });
            foreach (var d in join)
            {
                Console.WriteLine(d.eid + " " + d.ename + " " + d.lid + " "
                                  + d.ltype + " " + d.lreason);
            }
            




           Console.ReadLine();



        }
    }
}
