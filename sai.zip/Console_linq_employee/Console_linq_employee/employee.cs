﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_linq_employee
{
    class employee
    {
        public int employeeid { get; set; }
        public string employeename { get; set; }
        public int employeesalary { get; set; }
        public int employeeexp { get; set; }
        public string employeecity { get; set; }
    }
}
