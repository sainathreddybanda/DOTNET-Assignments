﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_linq_employee
{
    class employeedetails
    {
        public int empid { get; set; }
        public string empname { get; set; }
        public int empexp { get; set; }
    }
}
