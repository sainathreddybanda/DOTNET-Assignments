﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_linq_employee
{
    class employeeleave
    {
        public int eid { get; set; }
        public string ename { get; set; }
        public int lid { get; set; }
        public string ltype { get; set; }
        public string lreason { get; set; }
    }
}
