﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_linq_employee
{
    class leaves
    {
        public int leaveid { get; set; }
        public string leavetype { get; set; }
        public string leavereason { get; set; }
        public int empid { get; set; }
    }
}
