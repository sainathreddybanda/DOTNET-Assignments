﻿namespace WindowsForms_ado_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_employyname = new System.Windows.Forms.Label();
            this.lbl_employeecity = new System.Windows.Forms.Label();
            this.lbl_employeesalary = new System.Windows.Forms.Label();
            this.lbl_employeepassword = new System.Windows.Forms.Label();
            this.txt_empname = new System.Windows.Forms.TextBox();
            this.txt_empcity = new System.Windows.Forms.TextBox();
            this.txt_empsalary = new System.Windows.Forms.TextBox();
            this.txt_emppassword = new System.Windows.Forms.TextBox();
            this.lbl_login = new System.Windows.Forms.Label();
            this.lbl_password = new System.Windows.Forms.Label();
            this.txt_loginid = new System.Windows.Forms.TextBox();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.btn_newemployee = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_login = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_employyname
            // 
            this.lbl_employyname.AutoSize = true;
            this.lbl_employyname.Location = new System.Drawing.Point(46, 40);
            this.lbl_employyname.Name = "lbl_employyname";
            this.lbl_employyname.Size = new System.Drawing.Size(96, 13);
            this.lbl_employyname.TabIndex = 0;
            this.lbl_employyname.Text = "EMPLOYEENAME";
            this.lbl_employyname.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_employeecity
            // 
            this.lbl_employeecity.AutoSize = true;
            this.lbl_employeecity.Location = new System.Drawing.Point(46, 98);
            this.lbl_employeecity.Name = "lbl_employeecity";
            this.lbl_employeecity.Size = new System.Drawing.Size(89, 13);
            this.lbl_employeecity.TabIndex = 1;
            this.lbl_employeecity.Text = "EMPLOYEECITY";
            // 
            // lbl_employeesalary
            // 
            this.lbl_employeesalary.AutoSize = true;
            this.lbl_employeesalary.Location = new System.Drawing.Point(46, 159);
            this.lbl_employeesalary.Name = "lbl_employeesalary";
            this.lbl_employeesalary.Size = new System.Drawing.Size(107, 13);
            this.lbl_employeesalary.TabIndex = 2;
            this.lbl_employeesalary.Text = "EMPLOYEESALARY";
            // 
            // lbl_employeepassword
            // 
            this.lbl_employeepassword.AutoSize = true;
            this.lbl_employeepassword.Location = new System.Drawing.Point(46, 217);
            this.lbl_employeepassword.Name = "lbl_employeepassword";
            this.lbl_employeepassword.Size = new System.Drawing.Size(128, 13);
            this.lbl_employeepassword.TabIndex = 3;
            this.lbl_employeepassword.Text = "EMPLOYEEPASSWORD";
            // 
            // txt_empname
            // 
            this.txt_empname.Location = new System.Drawing.Point(224, 40);
            this.txt_empname.Name = "txt_empname";
            this.txt_empname.Size = new System.Drawing.Size(100, 20);
            this.txt_empname.TabIndex = 4;
            // 
            // txt_empcity
            // 
            this.txt_empcity.Location = new System.Drawing.Point(224, 95);
            this.txt_empcity.Name = "txt_empcity";
            this.txt_empcity.Size = new System.Drawing.Size(100, 20);
            this.txt_empcity.TabIndex = 5;
            // 
            // txt_empsalary
            // 
            this.txt_empsalary.Location = new System.Drawing.Point(224, 152);
            this.txt_empsalary.Name = "txt_empsalary";
            this.txt_empsalary.Size = new System.Drawing.Size(100, 20);
            this.txt_empsalary.TabIndex = 6;
            // 
            // txt_emppassword
            // 
            this.txt_emppassword.Location = new System.Drawing.Point(224, 214);
            this.txt_emppassword.Name = "txt_emppassword";
            this.txt_emppassword.Size = new System.Drawing.Size(100, 20);
            this.txt_emppassword.TabIndex = 7;
            // 
            // lbl_login
            // 
            this.lbl_login.AutoSize = true;
            this.lbl_login.Location = new System.Drawing.Point(430, 46);
            this.lbl_login.Name = "lbl_login";
            this.lbl_login.Size = new System.Drawing.Size(54, 13);
            this.lbl_login.TabIndex = 8;
            this.lbl_login.Text = "LOGIN ID";
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Location = new System.Drawing.Point(430, 102);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(70, 13);
            this.lbl_password.TabIndex = 9;
            this.lbl_password.Text = "PASSWORD";
            // 
            // txt_loginid
            // 
            this.txt_loginid.Location = new System.Drawing.Point(520, 46);
            this.txt_loginid.Name = "txt_loginid";
            this.txt_loginid.Size = new System.Drawing.Size(100, 20);
            this.txt_loginid.TabIndex = 10;
            // 
            // txt_password
            // 
            this.txt_password.Location = new System.Drawing.Point(520, 102);
            this.txt_password.Name = "txt_password";
            this.txt_password.Size = new System.Drawing.Size(100, 20);
            this.txt_password.TabIndex = 11;
            // 
            // btn_newemployee
            // 
            this.btn_newemployee.BackColor = System.Drawing.Color.Aquamarine;
            this.btn_newemployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newemployee.Location = new System.Drawing.Point(64, 283);
            this.btn_newemployee.Name = "btn_newemployee";
            this.btn_newemployee.Size = new System.Drawing.Size(195, 23);
            this.btn_newemployee.TabIndex = 12;
            this.btn_newemployee.Text = "NEW EMMPLOYEE";
            this.btn_newemployee.UseVisualStyleBackColor = false;
            this.btn_newemployee.Click += new System.EventHandler(this.btn_newemployee_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.BackColor = System.Drawing.Color.Aquamarine;
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(361, 283);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 23);
            this.btn_reset.TabIndex = 13;
            this.btn_reset.Text = "RESET";
            this.btn_reset.UseVisualStyleBackColor = false;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // btn_login
            // 
            this.btn_login.BackColor = System.Drawing.Color.Aquamarine;
            this.btn_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login.Location = new System.Drawing.Point(433, 152);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(75, 23);
            this.btn_login.TabIndex = 14;
            this.btn_login.Text = "LOGIN";
            this.btn_login.UseVisualStyleBackColor = false;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Aquamarine;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(575, 154);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 15;
            this.button1.Text = "LOGIN";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Bisque;
            this.ClientSize = new System.Drawing.Size(687, 325);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_newemployee);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.txt_loginid);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.lbl_login);
            this.Controls.Add(this.txt_emppassword);
            this.Controls.Add(this.txt_empsalary);
            this.Controls.Add(this.txt_empcity);
            this.Controls.Add(this.txt_empname);
            this.Controls.Add(this.lbl_employeepassword);
            this.Controls.Add(this.lbl_employeesalary);
            this.Controls.Add(this.lbl_employeecity);
            this.Controls.Add(this.lbl_employyname);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_employyname;
        private System.Windows.Forms.Label lbl_employeecity;
        private System.Windows.Forms.Label lbl_employeesalary;
        private System.Windows.Forms.Label lbl_employeepassword;
        private System.Windows.Forms.TextBox txt_empname;
        private System.Windows.Forms.TextBox txt_empcity;
        private System.Windows.Forms.TextBox txt_empsalary;
        private System.Windows.Forms.TextBox txt_emppassword;
        private System.Windows.Forms.Label lbl_login;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.TextBox txt_loginid;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.Button btn_newemployee;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button button1;
    }
}

