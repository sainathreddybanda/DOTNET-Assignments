﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_ado_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_newemployee_Click(object sender, EventArgs e)
        {
            if(txt_empname.Text==string.Empty)
            {
                MessageBox.Show("enter name");

            }
            else if (txt_empcity .Text == string.Empty)
            {
                MessageBox.Show("enter city");
            }
            else if(txt_empsalary.Text==string.Empty)
            {
                MessageBox.Show("enter salary");
            }
            else if(txt_emppassword.Text==string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else
            {
                employeemodel model = new employeemodel();
                model.employeename = txt_empname.Text;
                model.employeecity = txt_empcity.Text;
                model.employeesalary = Convert.ToInt32(txt_empsalary.Text);
                model.employeepassword = txt_emppassword.Text;
                employeesdal dal = new employeesdal();
                int id = dal.addemployee(model);
                MessageBox.Show("employee added :ID" + id);

            }
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if (txt_loginid.Text == string.Empty)
            {
                MessageBox.Show("enter login id");
            }
            if (txt_password.Text == string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else
            {

                int loginid = Convert.ToInt32(txt_loginid.Text);
                string password = txt_password.Text;
                employeesdal dal = new employeesdal();
                bool status = dal.login(loginid, password);
                if (status == true)
                {
                    MessageBox.Show("valid user");
                    Form_home obj = new Form_home();
                    obj.Show();
                }
                else
                {
                    MessageBox.Show("invalid user");
                }
            }
        }
        

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_empname.Text = string.Empty;
            txt_empcity.Text = string.Empty;
            txt_empsalary.Text = string.Empty;
            txt_emppassword.Text = string.Empty;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string id = txt_loginid.Text;
            string password = txt_password.Text;
            employeesdal dal = new employeesdal();
            bool status = dal.loginsqlinjection(id, password);
            if(status==true)
            {
                MessageBox.Show("valid user");
            }
            else
            {
                MessageBox.Show("invalid user");
            }
        }
    }
}
