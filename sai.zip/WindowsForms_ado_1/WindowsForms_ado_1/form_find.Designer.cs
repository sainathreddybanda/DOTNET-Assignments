﻿namespace WindowsForms_ado_1
{
    partial class form_find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_emppassword = new System.Windows.Forms.TextBox();
            this.txt_empsalary = new System.Windows.Forms.TextBox();
            this.txt_empcity = new System.Windows.Forms.TextBox();
            this.txt_empname = new System.Windows.Forms.TextBox();
            this.lbl_employeepassword = new System.Windows.Forms.Label();
            this.lbl_employeesalary = new System.Windows.Forms.Label();
            this.lbl_employeecity = new System.Windows.Forms.Label();
            this.lbl_employyname = new System.Windows.Forms.Label();
            this.lbl_empid = new System.Windows.Forms.Label();
            this.txt_empid = new System.Windows.Forms.TextBox();
            this.btn_find = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_emppassword
            // 
            this.txt_emppassword.Location = new System.Drawing.Point(291, 262);
            this.txt_emppassword.Name = "txt_emppassword";
            this.txt_emppassword.Size = new System.Drawing.Size(100, 20);
            this.txt_emppassword.TabIndex = 15;
            // 
            // txt_empsalary
            // 
            this.txt_empsalary.Location = new System.Drawing.Point(291, 208);
            this.txt_empsalary.Name = "txt_empsalary";
            this.txt_empsalary.Size = new System.Drawing.Size(100, 20);
            this.txt_empsalary.TabIndex = 14;
            // 
            // txt_empcity
            // 
            this.txt_empcity.Location = new System.Drawing.Point(291, 156);
            this.txt_empcity.Name = "txt_empcity";
            this.txt_empcity.Size = new System.Drawing.Size(100, 20);
            this.txt_empcity.TabIndex = 13;
            // 
            // txt_empname
            // 
            this.txt_empname.Location = new System.Drawing.Point(291, 101);
            this.txt_empname.Name = "txt_empname";
            this.txt_empname.Size = new System.Drawing.Size(100, 20);
            this.txt_empname.TabIndex = 12;
            // 
            // lbl_employeepassword
            // 
            this.lbl_employeepassword.AutoSize = true;
            this.lbl_employeepassword.Location = new System.Drawing.Point(93, 265);
            this.lbl_employeepassword.Name = "lbl_employeepassword";
            this.lbl_employeepassword.Size = new System.Drawing.Size(128, 13);
            this.lbl_employeepassword.TabIndex = 11;
            this.lbl_employeepassword.Text = "EMPLOYEEPASSWORD";
            // 
            // lbl_employeesalary
            // 
            this.lbl_employeesalary.AutoSize = true;
            this.lbl_employeesalary.Location = new System.Drawing.Point(114, 208);
            this.lbl_employeesalary.Name = "lbl_employeesalary";
            this.lbl_employeesalary.Size = new System.Drawing.Size(107, 13);
            this.lbl_employeesalary.TabIndex = 10;
            this.lbl_employeesalary.Text = "EMPLOYEESALARY";
            // 
            // lbl_employeecity
            // 
            this.lbl_employeecity.AutoSize = true;
            this.lbl_employeecity.Location = new System.Drawing.Point(132, 156);
            this.lbl_employeecity.Name = "lbl_employeecity";
            this.lbl_employeecity.Size = new System.Drawing.Size(89, 13);
            this.lbl_employeecity.TabIndex = 9;
            this.lbl_employeecity.Text = "EMPLOYEECITY";
            // 
            // lbl_employyname
            // 
            this.lbl_employyname.AutoSize = true;
            this.lbl_employyname.Location = new System.Drawing.Point(132, 104);
            this.lbl_employyname.Name = "lbl_employyname";
            this.lbl_employyname.Size = new System.Drawing.Size(96, 13);
            this.lbl_employyname.TabIndex = 8;
            this.lbl_employyname.Text = "EMPLOYEENAME";
            // 
            // lbl_empid
            // 
            this.lbl_empid.AutoSize = true;
            this.lbl_empid.Location = new System.Drawing.Point(142, 52);
            this.lbl_empid.Name = "lbl_empid";
            this.lbl_empid.Size = new System.Drawing.Size(79, 13);
            this.lbl_empid.TabIndex = 16;
            this.lbl_empid.Text = "EMPLOYEE ID";
            // 
            // txt_empid
            // 
            this.txt_empid.Location = new System.Drawing.Point(291, 52);
            this.txt_empid.Name = "txt_empid";
            this.txt_empid.Size = new System.Drawing.Size(100, 20);
            this.txt_empid.TabIndex = 17;
            // 
            // btn_find
            // 
            this.btn_find.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_find.Location = new System.Drawing.Point(472, 48);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(75, 23);
            this.btn_find.TabIndex = 18;
            this.btn_find.Text = "FIND";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // btn_update
            // 
            this.btn_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Location = new System.Drawing.Point(96, 332);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(97, 23);
            this.btn_update.TabIndex = 19;
            this.btn_update.Text = "UPDATE";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Location = new System.Drawing.Point(291, 332);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 23);
            this.btn_delete.TabIndex = 20;
            this.btn_delete.Text = "DELETE";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // form_find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 385);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.txt_empid);
            this.Controls.Add(this.lbl_empid);
            this.Controls.Add(this.txt_emppassword);
            this.Controls.Add(this.txt_empsalary);
            this.Controls.Add(this.txt_empcity);
            this.Controls.Add(this.txt_empname);
            this.Controls.Add(this.lbl_employeepassword);
            this.Controls.Add(this.lbl_employeesalary);
            this.Controls.Add(this.lbl_employeecity);
            this.Controls.Add(this.lbl_employyname);
            this.Name = "form_find";
            this.Text = "form_find";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_emppassword;
        private System.Windows.Forms.TextBox txt_empsalary;
        private System.Windows.Forms.TextBox txt_empcity;
        private System.Windows.Forms.TextBox txt_empname;
        private System.Windows.Forms.Label lbl_employeepassword;
        private System.Windows.Forms.Label lbl_employeesalary;
        private System.Windows.Forms.Label lbl_employeecity;
        private System.Windows.Forms.Label lbl_employyname;
        private System.Windows.Forms.Label lbl_empid;
        private System.Windows.Forms.TextBox txt_empid;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_delete;
    }
}