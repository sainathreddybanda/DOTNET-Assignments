﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_ado_1
{
    public partial class form_find : Form
    {
        public form_find()
        {
            InitializeComponent();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if(txt_empid.Text==string.Empty)
            {
                MessageBox.Show("enter employee id");
            }
            else
            {
                int id = Convert.ToInt32(txt_empid.Text);
                employeesdal dal = new employeesdal();
                employeemodel model = dal.findemployee(id);
                if(model!=null)
                {
                    txt_empname.Text = model.employeename;
                    txt_empcity.Text = model.employeecity;
                    txt_empsalary.Text = model.employeesalary.ToString();
                    txt_emppassword.Text = model.employeepassword;
                        }
                else
                {
                    MessageBox.Show("employee not found");
                }
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txt_empid.Text);
            string city = txt_empcity.Text;
            int salary = Convert.ToInt32(txt_empsalary.Text);
            employeesdal dal = new employeesdal();
            bool status = dal.updateemployee(id, city, salary);
            if(status==true)
            {
                MessageBox.Show("employee details updated");
            }
            else
            {
                MessageBox.Show("employee id is invalid");
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txt_empid.Text);
            employeesdal dal = new employeesdal();
            bool status = dal.deleteemployee(id);
            if(status==true)
            {
                MessageBox.Show("employee deleted");
            }
            else
            {
                MessageBox.Show("employee not deleted");
            }
        }
    }
}
