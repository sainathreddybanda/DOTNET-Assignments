﻿namespace WindowsForms_student
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_studentname = new System.Windows.Forms.Label();
            this.lbl_studentcity = new System.Windows.Forms.Label();
            this.lbl_studentaddress = new System.Windows.Forms.Label();
            this.lbl_studentemail = new System.Windows.Forms.Label();
            this.txt_studentname = new System.Windows.Forms.TextBox();
            this.txt_studentcity = new System.Windows.Forms.TextBox();
            this.txt_studentaddress = new System.Windows.Forms.TextBox();
            this.txt_studentemail = new System.Windows.Forms.TextBox();
            this.btn_newstudent = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_find = new System.Windows.Forms.Button();
            this.btn_search = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_studentname
            // 
            this.lbl_studentname.AutoSize = true;
            this.lbl_studentname.Location = new System.Drawing.Point(86, 28);
            this.lbl_studentname.Name = "lbl_studentname";
            this.lbl_studentname.Size = new System.Drawing.Size(93, 13);
            this.lbl_studentname.TabIndex = 0;
            this.lbl_studentname.Text = "STUDENT NAME";
            // 
            // lbl_studentcity
            // 
            this.lbl_studentcity.AutoSize = true;
            this.lbl_studentcity.Location = new System.Drawing.Point(93, 72);
            this.lbl_studentcity.Name = "lbl_studentcity";
            this.lbl_studentcity.Size = new System.Drawing.Size(86, 13);
            this.lbl_studentcity.TabIndex = 1;
            this.lbl_studentcity.Text = "STUDENT CITY";
            // 
            // lbl_studentaddress
            // 
            this.lbl_studentaddress.AutoSize = true;
            this.lbl_studentaddress.Location = new System.Drawing.Point(65, 123);
            this.lbl_studentaddress.Name = "lbl_studentaddress";
            this.lbl_studentaddress.Size = new System.Drawing.Size(114, 13);
            this.lbl_studentaddress.TabIndex = 2;
            this.lbl_studentaddress.Text = "STUDENT ADDRESS";
            // 
            // lbl_studentemail
            // 
            this.lbl_studentemail.AutoSize = true;
            this.lbl_studentemail.Location = new System.Drawing.Point(71, 178);
            this.lbl_studentemail.Name = "lbl_studentemail";
            this.lbl_studentemail.Size = new System.Drawing.Size(108, 13);
            this.lbl_studentemail.TabIndex = 3;
            this.lbl_studentemail.Text = "STUDENT EMAIL ID";
            // 
            // txt_studentname
            // 
            this.txt_studentname.Location = new System.Drawing.Point(298, 21);
            this.txt_studentname.Name = "txt_studentname";
            this.txt_studentname.Size = new System.Drawing.Size(100, 20);
            this.txt_studentname.TabIndex = 4;
            // 
            // txt_studentcity
            // 
            this.txt_studentcity.Location = new System.Drawing.Point(298, 69);
            this.txt_studentcity.Name = "txt_studentcity";
            this.txt_studentcity.Size = new System.Drawing.Size(100, 20);
            this.txt_studentcity.TabIndex = 5;
            // 
            // txt_studentaddress
            // 
            this.txt_studentaddress.Location = new System.Drawing.Point(298, 123);
            this.txt_studentaddress.Name = "txt_studentaddress";
            this.txt_studentaddress.Size = new System.Drawing.Size(100, 20);
            this.txt_studentaddress.TabIndex = 6;
            // 
            // txt_studentemail
            // 
            this.txt_studentemail.Location = new System.Drawing.Point(298, 178);
            this.txt_studentemail.Name = "txt_studentemail";
            this.txt_studentemail.Size = new System.Drawing.Size(100, 20);
            this.txt_studentemail.TabIndex = 7;
            // 
            // btn_newstudent
            // 
            this.btn_newstudent.Location = new System.Drawing.Point(12, 263);
            this.btn_newstudent.Name = "btn_newstudent";
            this.btn_newstudent.Size = new System.Drawing.Size(115, 23);
            this.btn_newstudent.TabIndex = 8;
            this.btn_newstudent.Text = "NEW STUDENT";
            this.btn_newstudent.UseVisualStyleBackColor = true;
            this.btn_newstudent.Click += new System.EventHandler(this.btn_newstudent_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Location = new System.Drawing.Point(183, 263);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 23);
            this.btn_reset.TabIndex = 9;
            this.btn_reset.Text = "RESET";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // btn_find
            // 
            this.btn_find.Location = new System.Drawing.Point(416, 263);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(75, 23);
            this.btn_find.TabIndex = 10;
            this.btn_find.Text = "FIND";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // btn_search
            // 
            this.btn_search.Location = new System.Drawing.Point(298, 263);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(75, 23);
            this.btn_search.TabIndex = 11;
            this.btn_search.Text = "SEARCH";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(523, 311);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_newstudent);
            this.Controls.Add(this.txt_studentemail);
            this.Controls.Add(this.txt_studentaddress);
            this.Controls.Add(this.txt_studentcity);
            this.Controls.Add(this.txt_studentname);
            this.Controls.Add(this.lbl_studentemail);
            this.Controls.Add(this.lbl_studentaddress);
            this.Controls.Add(this.lbl_studentcity);
            this.Controls.Add(this.lbl_studentname);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_studentname;
        private System.Windows.Forms.Label lbl_studentcity;
        private System.Windows.Forms.Label lbl_studentaddress;
        private System.Windows.Forms.Label lbl_studentemail;
        private System.Windows.Forms.TextBox txt_studentname;
        private System.Windows.Forms.TextBox txt_studentcity;
        private System.Windows.Forms.TextBox txt_studentaddress;
        private System.Windows.Forms.TextBox txt_studentemail;
        private System.Windows.Forms.Button btn_newstudent;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.Button btn_search;
    }
}

