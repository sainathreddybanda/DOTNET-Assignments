﻿namespace WindowsForms_student
{
    partial class frm_find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_studentemail = new System.Windows.Forms.TextBox();
            this.txt_studentaddress = new System.Windows.Forms.TextBox();
            this.txt_studentcity = new System.Windows.Forms.TextBox();
            this.txt_studentname = new System.Windows.Forms.TextBox();
            this.lbl_studentemail = new System.Windows.Forms.Label();
            this.lbl_studentaddress = new System.Windows.Forms.Label();
            this.lbl_studentcity = new System.Windows.Forms.Label();
            this.lbl_studentname = new System.Windows.Forms.Label();
            this.lbl_studentid = new System.Windows.Forms.Label();
            this.txt_studentid = new System.Windows.Forms.TextBox();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_find = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_studentemail
            // 
            this.txt_studentemail.Location = new System.Drawing.Point(365, 233);
            this.txt_studentemail.Name = "txt_studentemail";
            this.txt_studentemail.Size = new System.Drawing.Size(100, 20);
            this.txt_studentemail.TabIndex = 15;
            // 
            // txt_studentaddress
            // 
            this.txt_studentaddress.Location = new System.Drawing.Point(365, 181);
            this.txt_studentaddress.Name = "txt_studentaddress";
            this.txt_studentaddress.Size = new System.Drawing.Size(100, 20);
            this.txt_studentaddress.TabIndex = 14;
            // 
            // txt_studentcity
            // 
            this.txt_studentcity.Location = new System.Drawing.Point(365, 131);
            this.txt_studentcity.Name = "txt_studentcity";
            this.txt_studentcity.Size = new System.Drawing.Size(100, 20);
            this.txt_studentcity.TabIndex = 13;
            // 
            // txt_studentname
            // 
            this.txt_studentname.Location = new System.Drawing.Point(365, 79);
            this.txt_studentname.Name = "txt_studentname";
            this.txt_studentname.Size = new System.Drawing.Size(100, 20);
            this.txt_studentname.TabIndex = 12;
            // 
            // lbl_studentemail
            // 
            this.lbl_studentemail.AutoSize = true;
            this.lbl_studentemail.Location = new System.Drawing.Point(189, 240);
            this.lbl_studentemail.Name = "lbl_studentemail";
            this.lbl_studentemail.Size = new System.Drawing.Size(108, 13);
            this.lbl_studentemail.TabIndex = 11;
            this.lbl_studentemail.Text = "STUDENT EMAIL ID";
            // 
            // lbl_studentaddress
            // 
            this.lbl_studentaddress.AutoSize = true;
            this.lbl_studentaddress.Location = new System.Drawing.Point(189, 188);
            this.lbl_studentaddress.Name = "lbl_studentaddress";
            this.lbl_studentaddress.Size = new System.Drawing.Size(114, 13);
            this.lbl_studentaddress.TabIndex = 10;
            this.lbl_studentaddress.Text = "STUDENT ADDRESS";
            // 
            // lbl_studentcity
            // 
            this.lbl_studentcity.AutoSize = true;
            this.lbl_studentcity.Location = new System.Drawing.Point(189, 138);
            this.lbl_studentcity.Name = "lbl_studentcity";
            this.lbl_studentcity.Size = new System.Drawing.Size(86, 13);
            this.lbl_studentcity.TabIndex = 9;
            this.lbl_studentcity.Text = "STUDENT CITY";
            // 
            // lbl_studentname
            // 
            this.lbl_studentname.AutoSize = true;
            this.lbl_studentname.Location = new System.Drawing.Point(189, 86);
            this.lbl_studentname.Name = "lbl_studentname";
            this.lbl_studentname.Size = new System.Drawing.Size(93, 13);
            this.lbl_studentname.TabIndex = 8;
            this.lbl_studentname.Text = "STUDENT NAME";
            // 
            // lbl_studentid
            // 
            this.lbl_studentid.AutoSize = true;
            this.lbl_studentid.Location = new System.Drawing.Point(189, 31);
            this.lbl_studentid.Name = "lbl_studentid";
            this.lbl_studentid.Size = new System.Drawing.Size(73, 13);
            this.lbl_studentid.TabIndex = 16;
            this.lbl_studentid.Text = "STUDENT ID";
            // 
            // txt_studentid
            // 
            this.txt_studentid.Location = new System.Drawing.Point(365, 28);
            this.txt_studentid.Name = "txt_studentid";
            this.txt_studentid.Size = new System.Drawing.Size(100, 20);
            this.txt_studentid.TabIndex = 17;
            // 
            // btn_update
            // 
            this.btn_update.Location = new System.Drawing.Point(100, 282);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(75, 23);
            this.btn_update.TabIndex = 18;
            this.btn_update.Text = "UPDATE";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(313, 281);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 23);
            this.btn_delete.TabIndex = 19;
            this.btn_delete.Text = "DELETE";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_find
            // 
            this.btn_find.Location = new System.Drawing.Point(560, 20);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(75, 23);
            this.btn_find.TabIndex = 20;
            this.btn_find.Text = "FIND";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // frm_find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(694, 343);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.txt_studentid);
            this.Controls.Add(this.lbl_studentid);
            this.Controls.Add(this.txt_studentemail);
            this.Controls.Add(this.txt_studentaddress);
            this.Controls.Add(this.txt_studentcity);
            this.Controls.Add(this.txt_studentname);
            this.Controls.Add(this.lbl_studentemail);
            this.Controls.Add(this.lbl_studentaddress);
            this.Controls.Add(this.lbl_studentcity);
            this.Controls.Add(this.lbl_studentname);
            this.Name = "frm_find";
            this.Text = "frm_find";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_studentemail;
        private System.Windows.Forms.TextBox txt_studentaddress;
        private System.Windows.Forms.TextBox txt_studentcity;
        private System.Windows.Forms.TextBox txt_studentname;
        private System.Windows.Forms.Label lbl_studentemail;
        private System.Windows.Forms.Label lbl_studentaddress;
        private System.Windows.Forms.Label lbl_studentcity;
        private System.Windows.Forms.Label lbl_studentname;
        private System.Windows.Forms.Label lbl_studentid;
        private System.Windows.Forms.TextBox txt_studentid;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_find;
    }
}