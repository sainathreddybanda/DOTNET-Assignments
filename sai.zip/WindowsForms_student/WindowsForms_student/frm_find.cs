﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_student
{
    public partial class frm_find : Form
    {
        public frm_find()
        {
            InitializeComponent();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if(txt_studentid.Text==string.Empty)
            {
                MessageBox.Show("enter student id");
            }
            else
            {
                int id = Convert.ToInt32(txt_studentid.Text);
                studentdal dal = new studentdal();
                studentmodel model = dal.findstudent(id);
                if(model!=null)
                {
                    txt_studentname.Text = model.studentname;
                    txt_studentcity.Text = model.studentcity;
                    txt_studentaddress.Text = model.studentaddress;
                    txt_studentemail.Text = model.studentemailid;


                }
                else
                {
                    MessageBox.Show("student not found");
                }

            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txt_studentid.Text);
            string address = txt_studentaddress.Text;
            string city = txt_studentcity.Text;
            studentdal dal = new studentdal();
            bool status = dal.updatestudent(id, address, city);
            if(status==true)
            {
                MessageBox.Show("student details updated");
            }
            else
            {
                MessageBox.Show("student id is not valid");
            }

        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txt_studentid.Text);
            studentdal dal = new studentdal();
            bool status = dal.deletestudent(id);
            if(status==true)
            {
                MessageBox.Show("student details deleted");
            }
            else
            {
                MessageBox.Show("student id is invalid");
            }
        }
    }
}
