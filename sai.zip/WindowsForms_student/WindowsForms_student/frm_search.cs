﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_student
{
    public partial class frm_search : Form
    {
        public frm_search()
        {
            InitializeComponent();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            if(txt_key.Text==string.Empty)
            {
                MessageBox.Show("enter a key to search");
            }
            else
            {
                studentdal dal = new studentdal();
                string key = txt_key.Text;
                List<studentmodel> list = dal.searchstudent(key);
                dg_student.DataSource = list;
            }
        }
    }
}
