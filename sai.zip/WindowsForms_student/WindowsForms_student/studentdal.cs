﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
namespace WindowsForms_student
{
    class studentdal
    {
        SqlConnection con = new SqlConnection
            (ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
        public int addstudent(studentmodel model)
        {
            SqlCommand com_addstudent = new SqlCommand("proc_addstudent", con);
            com_addstudent.Parameters.AddWithValue("@name", model.studentname);
            com_addstudent.Parameters.AddWithValue("@city", model.studentcity);
            com_addstudent.Parameters.AddWithValue("@address", model.studentaddress);
            com_addstudent.Parameters.AddWithValue("@email",model.studentemailid);
            com_addstudent.CommandType = CommandType.StoredProcedure;
            SqlParameter para_return = new SqlParameter();
            para_return.Direction = ParameterDirection.ReturnValue;
            com_addstudent.Parameters.Add(para_return);
            con.Open();
            com_addstudent.ExecuteNonQuery();
            con.Close();
            int id = Convert.ToInt32(para_return.Value);
            return id;


        }

        public studentmodel findstudent(int id)
        {
            SqlCommand com_findstudent = new SqlCommand("proc_findstudent", con);
            com_findstudent.Parameters.AddWithValue("@id", id);
            com_findstudent.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_findstudent.ExecuteReader();
            if (dr.Read())
            {
                studentmodel model = new studentmodel();
                model.studentid = dr.GetInt32(0);
                model.studentname = dr.GetString(1);
                model.studentcity = dr.GetString(2);
                model.studentaddress = dr.GetString(3);
                model.studentemailid = dr.GetString(4);
                con.Close();
                return model;
            }
            else

            {
                con.Close();
                return null;
            }



        }

        public bool updatestudent(int id,string address,string city)
        {
            SqlCommand com_updatestudent = new SqlCommand("proc_updatestudent", con);
            com_updatestudent.Parameters.AddWithValue("@id", id);
            com_updatestudent.Parameters.AddWithValue("@address", address);
            com_updatestudent.Parameters.AddWithValue("@city", city);
            com_updatestudent.CommandType = CommandType.StoredProcedure;
            SqlParameter para_return = new SqlParameter();
            para_return.Direction = ParameterDirection.ReturnValue;
            com_updatestudent.Parameters.Add(para_return);
            con.Open();
            com_updatestudent.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(para_return.Value);
            if(count>0)
            {
                return true;
            }
            else
            {
                return false;
            }

                
        }

        public bool deletestudent(int id)
        {
            SqlCommand com_deletestudent = new SqlCommand("proc_deletestudent", con);
            com_deletestudent.Parameters.AddWithValue("@id", id);
            com_deletestudent.CommandType = CommandType.StoredProcedure;
            SqlParameter para_return = new SqlParameter();
            para_return.Direction = ParameterDirection.ReturnValue;
            com_deletestudent.Parameters.Add(para_return);
            con.Open();
            com_deletestudent.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(para_return.Value);
            if(count>0)
            {
                return true;
            }
            else
            {
                return false;
            }
            

            
        }

        public List<studentmodel> searchstudent(string key)
        {
            SqlCommand com_searchstudent = new SqlCommand("proc_searchstudent", con);
            com_searchstudent.Parameters.AddWithValue("@key", key);
            com_searchstudent.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_searchstudent.ExecuteReader();
            List<studentmodel> list = new List<studentmodel>();
            while (dr.Read())
            {
                studentmodel model = new studentmodel();
                model.studentid = dr.GetInt32(0);
                model.studentname = dr.GetString(1);
                model.studentcity = dr.GetString(2);
                model.studentaddress = dr.GetString(3);
                model.studentemailid = dr.GetString(4);
                list.Add(model);
            }
            
            
             
                con.Close();
                return list;
            
        }
    }
}
