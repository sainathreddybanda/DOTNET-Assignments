﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForms_student
{
    class studentmodel
    {
        public int studentid { get; set; }
        public string studentname { get; set; }
        public string studentcity { get; set; }
        public string studentaddress { get; set; }
        public string studentemailid { get; set; }

    }
}
