﻿namespace Windows_customer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_customername = new System.Windows.Forms.Label();
            this.lbl_customerpassword = new System.Windows.Forms.Label();
            this.lbl_customercity = new System.Windows.Forms.Label();
            this.lbl_customeraddress = new System.Windows.Forms.Label();
            this.lbl_customermobileno = new System.Windows.Forms.Label();
            this.lbl_customeremail = new System.Windows.Forms.Label();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.txt_customerpassword = new System.Windows.Forms.TextBox();
            this.txt_customercity = new System.Windows.Forms.TextBox();
            this.txt_customeraddress = new System.Windows.Forms.TextBox();
            this.txt_customemobileno = new System.Windows.Forms.TextBox();
            this.txt_customeremail = new System.Windows.Forms.TextBox();
            this.btn_newcustomer = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_login = new System.Windows.Forms.Button();
            this.lbl_loginid = new System.Windows.Forms.Label();
            this.lbl_password = new System.Windows.Forms.Label();
            this.txt_loginid = new System.Windows.Forms.TextBox();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.btn_newcust1 = new System.Windows.Forms.Button();
            this.btn_login1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Location = new System.Drawing.Point(39, 18);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(102, 13);
            this.lbl_customername.TabIndex = 0;
            this.lbl_customername.Text = "CUSTOMER NAME";
            // 
            // lbl_customerpassword
            // 
            this.lbl_customerpassword.AutoSize = true;
            this.lbl_customerpassword.Location = new System.Drawing.Point(39, 54);
            this.lbl_customerpassword.Name = "lbl_customerpassword";
            this.lbl_customerpassword.Size = new System.Drawing.Size(134, 13);
            this.lbl_customerpassword.TabIndex = 1;
            this.lbl_customerpassword.Text = "CUSTOMER PASSWORD";
            // 
            // lbl_customercity
            // 
            this.lbl_customercity.AutoSize = true;
            this.lbl_customercity.Location = new System.Drawing.Point(39, 103);
            this.lbl_customercity.Name = "lbl_customercity";
            this.lbl_customercity.Size = new System.Drawing.Size(95, 13);
            this.lbl_customercity.TabIndex = 2;
            this.lbl_customercity.Text = "CUSTOMER CITY";
            // 
            // lbl_customeraddress
            // 
            this.lbl_customeraddress.AutoSize = true;
            this.lbl_customeraddress.Location = new System.Drawing.Point(39, 147);
            this.lbl_customeraddress.Name = "lbl_customeraddress";
            this.lbl_customeraddress.Size = new System.Drawing.Size(123, 13);
            this.lbl_customeraddress.TabIndex = 3;
            this.lbl_customeraddress.Text = "CUSTOMER ADDRESS";
            // 
            // lbl_customermobileno
            // 
            this.lbl_customermobileno.AutoSize = true;
            this.lbl_customermobileno.Location = new System.Drawing.Point(39, 194);
            this.lbl_customermobileno.Name = "lbl_customermobileno";
            this.lbl_customermobileno.Size = new System.Drawing.Size(130, 13);
            this.lbl_customermobileno.TabIndex = 4;
            this.lbl_customermobileno.Text = "CUSTOMER MOBILE NO";
            // 
            // lbl_customeremail
            // 
            this.lbl_customeremail.AutoSize = true;
            this.lbl_customeremail.Location = new System.Drawing.Point(39, 241);
            this.lbl_customeremail.Name = "lbl_customeremail";
            this.lbl_customeremail.Size = new System.Drawing.Size(103, 13);
            this.lbl_customeremail.TabIndex = 5;
            this.lbl_customeremail.Text = "CUSTOMER EMAIL";
            // 
            // txt_customername
            // 
            this.txt_customername.Location = new System.Drawing.Point(238, 18);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(100, 20);
            this.txt_customername.TabIndex = 6;
            // 
            // txt_customerpassword
            // 
            this.txt_customerpassword.Location = new System.Drawing.Point(238, 54);
            this.txt_customerpassword.Name = "txt_customerpassword";
            this.txt_customerpassword.Size = new System.Drawing.Size(100, 20);
            this.txt_customerpassword.TabIndex = 7;
            // 
            // txt_customercity
            // 
            this.txt_customercity.Location = new System.Drawing.Point(238, 103);
            this.txt_customercity.Name = "txt_customercity";
            this.txt_customercity.Size = new System.Drawing.Size(100, 20);
            this.txt_customercity.TabIndex = 8;
            // 
            // txt_customeraddress
            // 
            this.txt_customeraddress.Location = new System.Drawing.Point(238, 140);
            this.txt_customeraddress.Name = "txt_customeraddress";
            this.txt_customeraddress.Size = new System.Drawing.Size(100, 20);
            this.txt_customeraddress.TabIndex = 9;
            // 
            // txt_customemobileno
            // 
            this.txt_customemobileno.Location = new System.Drawing.Point(238, 187);
            this.txt_customemobileno.Name = "txt_customemobileno";
            this.txt_customemobileno.Size = new System.Drawing.Size(100, 20);
            this.txt_customemobileno.TabIndex = 10;
            // 
            // txt_customeremail
            // 
            this.txt_customeremail.Location = new System.Drawing.Point(238, 233);
            this.txt_customeremail.Name = "txt_customeremail";
            this.txt_customeremail.Size = new System.Drawing.Size(100, 20);
            this.txt_customeremail.TabIndex = 11;
            // 
            // btn_newcustomer
            // 
            this.btn_newcustomer.Location = new System.Drawing.Point(158, 284);
            this.btn_newcustomer.Name = "btn_newcustomer";
            this.btn_newcustomer.Size = new System.Drawing.Size(114, 23);
            this.btn_newcustomer.TabIndex = 12;
            this.btn_newcustomer.Text = "NEW CUSTOMER";
            this.btn_newcustomer.UseVisualStyleBackColor = true;
            this.btn_newcustomer.Click += new System.EventHandler(this.btn_newcustomer_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Location = new System.Drawing.Point(291, 284);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 23);
            this.btn_reset.TabIndex = 13;
            this.btn_reset.Text = "RESET";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(450, 147);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(75, 23);
            this.btn_login.TabIndex = 14;
            this.btn_login.Text = "LOGIN";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // lbl_loginid
            // 
            this.lbl_loginid.AutoSize = true;
            this.lbl_loginid.Location = new System.Drawing.Point(423, 33);
            this.lbl_loginid.Name = "lbl_loginid";
            this.lbl_loginid.Size = new System.Drawing.Size(54, 13);
            this.lbl_loginid.TabIndex = 15;
            this.lbl_loginid.Text = "LOGIN ID";
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Location = new System.Drawing.Point(423, 90);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(70, 13);
            this.lbl_password.TabIndex = 16;
            this.lbl_password.Text = "PASSWORD";
            // 
            // txt_loginid
            // 
            this.txt_loginid.Location = new System.Drawing.Point(517, 30);
            this.txt_loginid.Name = "txt_loginid";
            this.txt_loginid.Size = new System.Drawing.Size(100, 20);
            this.txt_loginid.TabIndex = 17;
            // 
            // txt_password
            // 
            this.txt_password.Location = new System.Drawing.Point(517, 87);
            this.txt_password.Name = "txt_password";
            this.txt_password.Size = new System.Drawing.Size(100, 20);
            this.txt_password.TabIndex = 18;
            // 
            // btn_newcust1
            // 
          //  this.btn_newcust1.Location = new System.Drawing.Point(30, 283);
            //this.btn_newcust1.Name = "btn_newcust1";
            //this.btn_newcust1.Size = new System.Drawing.Size(112, 23);
            //this.btn_newcust1.TabIndex = 19;
          //  this.btn_newcust1.Text = "NEWCUSTOMER1";
          //  this.btn_newcust1.UseVisualStyleBackColor = true;
         //   this.btn_newcust1.Click += new System.EventHandler(this.btn_newcust1_Click);
            // 
            // btn_login1
            // 
          //  this.btn_login1.Location = new System.Drawing.Point(568, 146);
          //  this.btn_login1.Name = "btn_login1";
          //  this.btn_login1.Size = new System.Drawing.Size(75, 23);
            //this.btn_login1.TabIndex = 20;
            //this.btn_login1.Text = "LOGIN1";
            //this.btn_login1.UseVisualStyleBackColor = true;
            //this.btn_login1.Click += new System.EventHandler(this.btn_login1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(669, 322);
            this.Controls.Add(this.btn_login1);
            this.Controls.Add(this.btn_newcust1);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.txt_loginid);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.lbl_loginid);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_newcustomer);
            this.Controls.Add(this.txt_customeremail);
            this.Controls.Add(this.txt_customemobileno);
            this.Controls.Add(this.txt_customeraddress);
            this.Controls.Add(this.txt_customercity);
            this.Controls.Add(this.txt_customerpassword);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.lbl_customeremail);
            this.Controls.Add(this.lbl_customermobileno);
            this.Controls.Add(this.lbl_customeraddress);
            this.Controls.Add(this.lbl_customercity);
            this.Controls.Add(this.lbl_customerpassword);
            this.Controls.Add(this.lbl_customername);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Label lbl_customerpassword;
        private System.Windows.Forms.Label lbl_customercity;
        private System.Windows.Forms.Label lbl_customeraddress;
        private System.Windows.Forms.Label lbl_customermobileno;
        private System.Windows.Forms.Label lbl_customeremail;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.TextBox txt_customerpassword;
        private System.Windows.Forms.TextBox txt_customercity;
        private System.Windows.Forms.TextBox txt_customeraddress;
        private System.Windows.Forms.TextBox txt_customemobileno;
        private System.Windows.Forms.TextBox txt_customeremail;
        private System.Windows.Forms.Button btn_newcustomer;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Label lbl_loginid;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.TextBox txt_loginid;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.Button btn_newcust1;
        private System.Windows.Forms.Button btn_login1;
    }
}

