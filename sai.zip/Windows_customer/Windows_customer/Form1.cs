﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_customer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_newcustomer_Click(object sender, EventArgs e)
        {
            if(txt_customername.Text==string.Empty)
            {
                MessageBox.Show("enter customer name");
            }
            else if(txt_customerpassword.Text==string.Empty)
            {
                MessageBox.Show("enter customer password");
            }
            else if(txt_customercity.Text==string.Empty)
            {
                MessageBox.Show("enter customer city");
            }
            else if(txt_customeraddress.Text==string.Empty)
            {
                MessageBox.Show("enter customer address");
            }
            else if(txt_customemobileno.Text==string.Empty)
            {
                MessageBox.Show("enter customer mobile number");
            }
            else if(txt_customeremail.Text==string.Empty)
            {
                MessageBox.Show("enter customer email");
            }
            else
            {
                customermodel model = new customermodel();
                model.customername = txt_customername.Text;
                model.customerpassword = txt_customerpassword.Text;
                model.customercity = txt_customercity.Text;
                model.customeraddress = txt_customeraddress.Text;
                model.customermobileno = txt_customemobileno.Text;
                model.customeremailid = txt_customeremail.Text;
                customerdal dal = new customerdal();
                int id = dal.addcustomer(model);
                MessageBox.Show("customer added :ID" + id);

            }
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if(txt_loginid.Text==string.Empty)
            {
                MessageBox.Show("enter login id");
            }
            else if(txt_password.Text==string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else
            {
                int loginid = Convert.ToInt32(txt_loginid.Text);
                string password = txt_password.Text;
                customerdal dal = new customerdal();
                bool status = dal.login(loginid, password);
                if(status==true)
                {
                    MessageBox.Show("valid user");
                    frm_home obj = new frm_home();
                    obj.Show();
                }
                else
                {
                    MessageBox.Show("invalid user");
                }
            }
                   
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_customername.Text = string.Empty;
            txt_customerpassword.Text = String.Empty;
            txt_customercity.Text = string.Empty;
            txt_customeraddress.Text = string.Empty;
            txt_customemobileno.Text = string.Empty;
            txt_customeremail.Text = String.Empty;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

      /*  private void btn_newcust1_Click(object sender, EventArgs e)
        {
            if (txt_customername.Text == string.Empty)
            {
                MessageBox.Show("enter customer name");
            }
            else if (txt_customerpassword.Text == string.Empty)
            {
                MessageBox.Show("enter customer password");
            }
            else if (txt_customercity.Text == string.Empty)
            {
                MessageBox.Show("enter customer city");
            }
            else if (txt_customeraddress.Text == string.Empty)
            {
                MessageBox.Show("enter customer address");
            }
            else if (txt_customemobileno.Text == string.Empty)
            {
                MessageBox.Show("enter customer mobile number");
            }
            else if (txt_customeremail.Text == string.Empty)
            {
                MessageBox.Show("enter customer email");
            }
            else
            {
                customermodel model = new customermodel();
                model.customername = txt_customername.Text;
                model.customerpassword = txt_customerpassword.Text;
                model.customercity = txt_customercity.Text;
                model.customeraddress = txt_customeraddress.Text;
                model.customermobileno = txt_customemobileno.Text;
                model.customeremailid = txt_customeremail.Text;
                customerdal dal = new customerdal();
                Task<int> id = dal.addcustomerasync(model);
                MessageBox.Show("customer added :ID" + id);

            }
        }

        private void btn_login1_Click(object sender, EventArgs e)
        {
            if (txt_loginid.Text == string.Empty)
            {
                MessageBox.Show("enter login id");
            }
            else if (txt_password.Text == string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else
            {
                int loginid = Convert.ToInt32(txt_loginid.Text);
                string password = txt_password.Text;
                customerdal dal = new customerdal();
                bool status = dal.login(loginid, password);
                if (status == true)
                {
                    MessageBox.Show("valid user");
                    frm_home obj = new frm_home();
                    obj.Show();
                }
                else
                {
                    MessageBox.Show("invalid user");
                }
            }*/

        }
    }


