﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Windows_customer
{
    class customermodel
    {
        public int customerid { get; set; }
        public string customername { get; set; }
        public string customerpassword { get; set; }
        public string customercity { get; set; }
        public string customeraddress { get; set; }
        public string customermobileno { get; set; }
        public string customeremailid { get; set; }
    }
}
