﻿namespace Windows_customer
{
    partial class form_find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_customeremail = new System.Windows.Forms.TextBox();
            this.txt_customemobileno = new System.Windows.Forms.TextBox();
            this.txt_customeraddress = new System.Windows.Forms.TextBox();
            this.txt_customercity = new System.Windows.Forms.TextBox();
            this.txt_customerpassword = new System.Windows.Forms.TextBox();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.lbl_customeremail = new System.Windows.Forms.Label();
            this.lbl_customermobileno = new System.Windows.Forms.Label();
            this.lbl_customeraddress = new System.Windows.Forms.Label();
            this.lbl_customercity = new System.Windows.Forms.Label();
            this.lbl_customerpassword = new System.Windows.Forms.Label();
            this.lbl_customername = new System.Windows.Forms.Label();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_find = new System.Windows.Forms.Button();
            this.lbl_customerid = new System.Windows.Forms.Label();
            this.txt_customerid = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txt_customeremail
            // 
            this.txt_customeremail.Location = new System.Drawing.Point(347, 291);
            this.txt_customeremail.Name = "txt_customeremail";
            this.txt_customeremail.Size = new System.Drawing.Size(100, 20);
            this.txt_customeremail.TabIndex = 23;
            // 
            // txt_customemobileno
            // 
            this.txt_customemobileno.Location = new System.Drawing.Point(347, 245);
            this.txt_customemobileno.Name = "txt_customemobileno";
            this.txt_customemobileno.Size = new System.Drawing.Size(100, 20);
            this.txt_customemobileno.TabIndex = 22;
            // 
            // txt_customeraddress
            // 
            this.txt_customeraddress.Location = new System.Drawing.Point(347, 198);
            this.txt_customeraddress.Name = "txt_customeraddress";
            this.txt_customeraddress.Size = new System.Drawing.Size(100, 20);
            this.txt_customeraddress.TabIndex = 21;
            // 
            // txt_customercity
            // 
            this.txt_customercity.Location = new System.Drawing.Point(347, 161);
            this.txt_customercity.Name = "txt_customercity";
            this.txt_customercity.Size = new System.Drawing.Size(100, 20);
            this.txt_customercity.TabIndex = 20;
            // 
            // txt_customerpassword
            // 
            this.txt_customerpassword.Location = new System.Drawing.Point(347, 112);
            this.txt_customerpassword.Name = "txt_customerpassword";
            this.txt_customerpassword.Size = new System.Drawing.Size(100, 20);
            this.txt_customerpassword.TabIndex = 19;
            // 
            // txt_customername
            // 
            this.txt_customername.Location = new System.Drawing.Point(347, 76);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(100, 20);
            this.txt_customername.TabIndex = 18;
            // 
            // lbl_customeremail
            // 
            this.lbl_customeremail.AutoSize = true;
            this.lbl_customeremail.Location = new System.Drawing.Point(148, 299);
            this.lbl_customeremail.Name = "lbl_customeremail";
            this.lbl_customeremail.Size = new System.Drawing.Size(103, 13);
            this.lbl_customeremail.TabIndex = 17;
            this.lbl_customeremail.Text = "CUSTOMER EMAIL";
            // 
            // lbl_customermobileno
            // 
            this.lbl_customermobileno.AutoSize = true;
            this.lbl_customermobileno.Location = new System.Drawing.Point(148, 252);
            this.lbl_customermobileno.Name = "lbl_customermobileno";
            this.lbl_customermobileno.Size = new System.Drawing.Size(130, 13);
            this.lbl_customermobileno.TabIndex = 16;
            this.lbl_customermobileno.Text = "CUSTOMER MOBILE NO";
            // 
            // lbl_customeraddress
            // 
            this.lbl_customeraddress.AutoSize = true;
            this.lbl_customeraddress.Location = new System.Drawing.Point(148, 205);
            this.lbl_customeraddress.Name = "lbl_customeraddress";
            this.lbl_customeraddress.Size = new System.Drawing.Size(123, 13);
            this.lbl_customeraddress.TabIndex = 15;
            this.lbl_customeraddress.Text = "CUSTOMER ADDRESS";
            // 
            // lbl_customercity
            // 
            this.lbl_customercity.AutoSize = true;
            this.lbl_customercity.Location = new System.Drawing.Point(148, 161);
            this.lbl_customercity.Name = "lbl_customercity";
            this.lbl_customercity.Size = new System.Drawing.Size(95, 13);
            this.lbl_customercity.TabIndex = 14;
            this.lbl_customercity.Text = "CUSTOMER CITY";
            // 
            // lbl_customerpassword
            // 
            this.lbl_customerpassword.AutoSize = true;
            this.lbl_customerpassword.Location = new System.Drawing.Point(148, 112);
            this.lbl_customerpassword.Name = "lbl_customerpassword";
            this.lbl_customerpassword.Size = new System.Drawing.Size(134, 13);
            this.lbl_customerpassword.TabIndex = 13;
            this.lbl_customerpassword.Text = "CUSTOMER PASSWORD";
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Location = new System.Drawing.Point(148, 76);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(102, 13);
            this.lbl_customername.TabIndex = 12;
            this.lbl_customername.Text = "CUSTOMER NAME";
            // 
            // btn_update
            // 
            this.btn_update.Location = new System.Drawing.Point(122, 346);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(75, 23);
            this.btn_update.TabIndex = 24;
            this.btn_update.Text = "UPDATE";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(315, 345);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 23);
            this.btn_delete.TabIndex = 25;
            this.btn_delete.Text = "DELETE";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_find
            // 
            this.btn_find.Location = new System.Drawing.Point(494, 22);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(75, 23);
            this.btn_find.TabIndex = 26;
            this.btn_find.Text = "FIND";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // lbl_customerid
            // 
            this.lbl_customerid.AutoSize = true;
            this.lbl_customerid.Location = new System.Drawing.Point(135, 29);
            this.lbl_customerid.Name = "lbl_customerid";
            this.lbl_customerid.Size = new System.Drawing.Size(82, 13);
            this.lbl_customerid.TabIndex = 30;
            this.lbl_customerid.Text = "CUSTOMER ID";
            // 
            // txt_customerid
            // 
            this.txt_customerid.Location = new System.Drawing.Point(328, 22);
            this.txt_customerid.Name = "txt_customerid";
            this.txt_customerid.Size = new System.Drawing.Size(100, 20);
            this.txt_customerid.TabIndex = 31;
            // 
            // form_find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(595, 389);
            this.Controls.Add(this.txt_customerid);
            this.Controls.Add(this.lbl_customerid);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.txt_customeremail);
            this.Controls.Add(this.txt_customemobileno);
            this.Controls.Add(this.txt_customeraddress);
            this.Controls.Add(this.txt_customercity);
            this.Controls.Add(this.txt_customerpassword);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.lbl_customeremail);
            this.Controls.Add(this.lbl_customermobileno);
            this.Controls.Add(this.lbl_customeraddress);
            this.Controls.Add(this.lbl_customercity);
            this.Controls.Add(this.lbl_customerpassword);
            this.Controls.Add(this.lbl_customername);
            this.Name = "form_find";
            this.Text = "form_find";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_customeremail;
        private System.Windows.Forms.TextBox txt_customemobileno;
        private System.Windows.Forms.TextBox txt_customeraddress;
        private System.Windows.Forms.TextBox txt_customercity;
        private System.Windows.Forms.TextBox txt_customerpassword;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.Label lbl_customeremail;
        private System.Windows.Forms.Label lbl_customermobileno;
        private System.Windows.Forms.Label lbl_customeraddress;
        private System.Windows.Forms.Label lbl_customercity;
        private System.Windows.Forms.Label lbl_customerpassword;
        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.Label lbl_customerid;
        private System.Windows.Forms.TextBox txt_customerid;
    }
}