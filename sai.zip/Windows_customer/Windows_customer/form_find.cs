﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_customer
{
    public partial class form_find : Form
    {
        public form_find()
        {
            InitializeComponent();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if(txt_customerid.Text==string.Empty)
            {
                MessageBox.Show("enter customer id");
            }
            else
            {
                int id = Convert.ToInt32(txt_customerid.Text);
                customerdal dal = new customerdal();
                customermodel model = dal.findcustomer(id);
                if (model != null)
                {
                    txt_customername.Text = model.customername;
                    txt_customerpassword.Text = model.customerpassword;
                    txt_customercity.Text = model.customercity;
                    txt_customeraddress.Text = model.customeraddress;
                    txt_customemobileno.Text = model.customermobileno;
                    txt_customeremail.Text = model.customeremailid;

                }
                else
                {
                    MessageBox.Show("customer not found");
                }
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txt_customerid.Text);
            string address = txt_customeraddress.Text;
            string mobileno = txt_customemobileno.Text;
            customerdal dal = new customerdal();
            bool status = dal.updatecustomer(id, address, mobileno);
if(status==true)
            {
                MessageBox.Show("customer details updated");
            }
else
            {
                MessageBox.Show("customer id is invalid");
            }
               
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txt_customerid.Text);
            customerdal dal = new customerdal();
            bool status = dal.deletecustomer(id);
            if(status==true)
            {
                MessageBox.Show("customer deleted");
            }
            else
            {
                MessageBox.Show("customer id is inavlid");
            }
        }
    }
}
