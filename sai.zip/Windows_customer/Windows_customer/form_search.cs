﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_customer
{
    public partial class form_search : Form
    {
        public form_search()
        {
            InitializeComponent();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            if(txt_key.Text==string.Empty)
            {
                MessageBox.Show("enter a key");
            }
            else
            {
                customerdal dal = new customerdal();
                string key = txt_key.Text;
                List<customermodel> list = dal.searchemployee(key);
                dg_customers.DataSource = list;
            }
        }
    }
}
