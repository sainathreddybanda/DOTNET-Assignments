﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_customer
{
    public partial class frm_home : Form
    {
        public frm_home()
        {
            InitializeComponent();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            form_find obj = new form_find();
            obj.Show();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            form_search obj = new form_search();
            obj.Show();
        }
    }
}
