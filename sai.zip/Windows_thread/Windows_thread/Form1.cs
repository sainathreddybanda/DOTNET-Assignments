﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Windows_thread
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_newthread_Click(object sender, EventArgs e)
        {
            Thread th = new Thread(this.call);
            th.Start();
            MessageBox.Show("main thread"+Thread.CurrentThread.ManagedThreadId);
            th.Join();
            MessageBox.Show("sainath"+ Thread.CurrentThread.ManagedThreadId);

        }

        public void call()
        {
            MessageBox.Show("new thread task"+ Thread.CurrentThread.ManagedThreadId);
            Thread.Sleep(10000);

            MessageBox.Show("hello ");
            
        }
    }
}
