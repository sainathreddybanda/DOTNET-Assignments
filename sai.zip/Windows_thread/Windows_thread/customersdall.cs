﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Windows_thread
{
    class customersdall
    {
        public Task<int> Addcustomerasync()
        {
            Task<int> t = Task.Run(() =>
            {
//ado.net
                return 1000;
            });
            return t;
        }
    }
}
