﻿namespace Windows_thread
{
    partial class frm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_thread1 = new System.Windows.Forms.Button();
            this.btn_thread2 = new System.Windows.Forms.Button();
            this.lbl_number1 = new System.Windows.Forms.Label();
            this.lbl_number2 = new System.Windows.Forms.Label();
            this.txt_number1 = new System.Windows.Forms.TextBox();
            this.txt_number2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_thread1
            // 
            this.btn_thread1.Location = new System.Drawing.Point(69, 228);
            this.btn_thread1.Name = "btn_thread1";
            this.btn_thread1.Size = new System.Drawing.Size(75, 23);
            this.btn_thread1.TabIndex = 0;
            this.btn_thread1.Text = "THREAD !";
            this.btn_thread1.UseVisualStyleBackColor = true;
            this.btn_thread1.Click += new System.EventHandler(this.btn_thread1_Click);
            // 
            // btn_thread2
            // 
            this.btn_thread2.Location = new System.Drawing.Point(345, 228);
            this.btn_thread2.Name = "btn_thread2";
            this.btn_thread2.Size = new System.Drawing.Size(75, 23);
            this.btn_thread2.TabIndex = 1;
            this.btn_thread2.Text = "THREAD 2";
            this.btn_thread2.UseVisualStyleBackColor = true;
            this.btn_thread2.Click += new System.EventHandler(this.btn_thread2_Click);
            // 
            // lbl_number1
            // 
            this.lbl_number1.AutoSize = true;
            this.lbl_number1.Location = new System.Drawing.Point(69, 47);
            this.lbl_number1.Name = "lbl_number1";
            this.lbl_number1.Size = new System.Drawing.Size(60, 13);
            this.lbl_number1.TabIndex = 2;
            this.lbl_number1.Text = "NUMBER !";
            // 
            // lbl_number2
            // 
            this.lbl_number2.AutoSize = true;
            this.lbl_number2.Location = new System.Drawing.Point(72, 121);
            this.lbl_number2.Name = "lbl_number2";
            this.lbl_number2.Size = new System.Drawing.Size(63, 13);
            this.lbl_number2.TabIndex = 3;
            this.lbl_number2.Text = "NUMBER 2";
            // 
            // txt_number1
            // 
            this.txt_number1.Location = new System.Drawing.Point(252, 39);
            this.txt_number1.Name = "txt_number1";
            this.txt_number1.Size = new System.Drawing.Size(100, 20);
            this.txt_number1.TabIndex = 4;
            // 
            // txt_number2
            // 
            this.txt_number2.Location = new System.Drawing.Point(252, 121);
            this.txt_number2.Name = "txt_number2";
            this.txt_number2.Size = new System.Drawing.Size(100, 20);
            this.txt_number2.TabIndex = 5;
            // 
            // frm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(538, 327);
            this.Controls.Add(this.txt_number2);
            this.Controls.Add(this.txt_number1);
            this.Controls.Add(this.lbl_number2);
            this.Controls.Add(this.lbl_number1);
            this.Controls.Add(this.btn_thread2);
            this.Controls.Add(this.btn_thread1);
            this.Name = "frm";
            this.Text = "frm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_thread1;
        private System.Windows.Forms.Button btn_thread2;
        private System.Windows.Forms.Label lbl_number1;
        private System.Windows.Forms.Label lbl_number2;
        private System.Windows.Forms.TextBox txt_number1;
        private System.Windows.Forms.TextBox txt_number2;
    }
}