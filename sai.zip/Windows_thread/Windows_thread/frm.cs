﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Windows_thread
{
    public partial class frm : Form
    {
        public frm()
        {
            InitializeComponent();
        }
        int total = 0;
        public void sum()
        {
            //  lock (this)
            //{
            if(Monitor.TryEnter(this,3000))
            { 
                int num1 = Convert.ToInt32(txt_number1.Text);
                int num2 = Convert.ToInt32(txt_number2.Text);
                total = num1 + num2;
                Thread.Sleep(15000);
                MessageBox.Show("total :" + total);
            Monitor.Exit(this);
            }
            else
            {
                MessageBox.Show("busy");
            }
        }
        private void btn_thread1_Click(object sender, EventArgs e)
        {
            Thread th1 = new Thread(sum);
            th1.Start();
        }

        private void btn_thread2_Click(object sender, EventArgs e)
        {
            Thread th2 = new Thread(sum);
            th2.Start();
        }
    }
}
