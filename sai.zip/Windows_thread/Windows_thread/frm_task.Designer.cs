﻿namespace Windows_thread
{
    partial class frm_task
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_task = new System.Windows.Forms.Button();
            this.btn_task2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_task
            // 
            this.btn_task.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_task.Location = new System.Drawing.Point(66, 48);
            this.btn_task.Name = "btn_task";
            this.btn_task.Size = new System.Drawing.Size(388, 38);
            this.btn_task.TabIndex = 0;
            this.btn_task.Text = "TASK";
            this.btn_task.UseVisualStyleBackColor = true;
            this.btn_task.Click += new System.EventHandler(this.btn_task_Click);
            // 
            // btn_task2
            // 
            this.btn_task2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_task2.Location = new System.Drawing.Point(66, 150);
            this.btn_task2.Name = "btn_task2";
            this.btn_task2.Size = new System.Drawing.Size(388, 38);
            this.btn_task2.TabIndex = 1;
            this.btn_task2.Text = "TASK";
            this.btn_task2.UseVisualStyleBackColor = true;
            this.btn_task2.Click += new System.EventHandler(this.btn_task2_Click);
            // 
            // frm_task
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(570, 261);
            this.Controls.Add(this.btn_task2);
            this.Controls.Add(this.btn_task);
            this.Name = "frm_task";
            this.Text = "frm_task";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_task;
        private System.Windows.Forms.Button btn_task2;
    }
}