﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_thread
{
    public partial class frm_task : Form
    {
        public frm_task()
        {
            InitializeComponent();
        }

        private async void btn_task_Click(object sender, EventArgs e)
        {
            Task t = Task.Run(()=> {
                MessageBox.Show("task started");
                MessageBox.Show("task completed");
                    });
            MessageBox.Show("main thread work1");
            await t;
            MessageBox.Show("main thread work2");
        }

        private async void btn_task2_Click(object sender, EventArgs e)
        {
            customersdall dal = new customersdall();
            var t = dal.Addcustomerasync();
            MessageBox.Show("some other work");

            int id = await t;
            MessageBox.Show("id:" + id);
             
        }
    }
}
