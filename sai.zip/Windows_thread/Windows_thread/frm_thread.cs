﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Windows_thread
{
    public partial class frm_thread : Form
    {
        public frm_thread()
        {
            InitializeComponent();
        }
        public void call(object obj)
        {
            MessageBox.Show("thread pool  id:"
                + Thread.CurrentThread.ManagedThreadId + "counter:" + obj);
        }

        private void btn_threadpool_Click(object sender, EventArgs e)
        {
            ThreadPool.SetMaxThreads(10, 1000);
            ThreadPool.SetMinThreads(5, 1000);
            int count = 0;
            while(count<20)
            {
                ThreadPool.QueueUserWorkItem(call, count);
                count++;
            }
        }
    }
}
