﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_thread_task_assignment
{
    public partial class Form1 : Form
    {
        calcitask obj = new calcitask();
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        
        private async void btn_add_Click(object sender, EventArgs e)
        {
            double d1 = Convert.ToDouble(txtbtn_num1.Text);
            double d2 = Convert.ToDouble(txt_num2.Text);

            var t = obj.getcalcasync(d1, d2, "+");
            var result = await t;
            lstbx_result.Items.Add("result of" + d1 + "+" + d2 + ":" + result);
        }

        private async void btn_sub_Click(object sender, EventArgs e)
        {
            double d1 = Convert.ToDouble(txtbtn_num1.Text);
            double d2 = Convert.ToDouble(txt_num2.Text);

            var t = obj.getcalcasync(d1, d2, "-");
            var result = await t;
            lstbx_result.Items.Add("result of" + d1 + "-" + d2 + ":" + result);
        }

        private async void btn_mul_Click(object sender, EventArgs e)
        {
            double d1 = Convert.ToDouble(txtbtn_num1.Text);
            double d2 = Convert.ToDouble(txt_num2.Text);

            var t = obj.getcalcasync(d1, d2, "*");
            var result = await t;
            lstbx_result.Items.Add("result of" + d1 + "*" + d2 + ":" + result);
        }

        private async void btn_div_Click(object sender, EventArgs e)
        {
            double d1 = Convert.ToDouble(txtbtn_num1.Text);
            double d2 = Convert.ToDouble(txt_num2.Text);

            var t = obj.getcalcasync(d1, d2, "/");
            var result = await t;
            lstbx_result.Items.Add("result of" + d1 + "/" + d2 + ":" + result);
        }

    
}
}
