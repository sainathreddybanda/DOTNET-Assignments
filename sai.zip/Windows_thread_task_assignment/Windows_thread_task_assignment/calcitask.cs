﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Windows_thread_task_assignment
{
    class calcitask
    {
        public Task<double> getcalcasync(double num1,double num2,string opt)
        {
            Task<double> t = Task.Run(() =>
            {
                Thread.Sleep(3000);
                double result = 0;
                switch(opt)
                {
                    case "+":
                        {
                            result = num1 + num2;
                            break;
                        }
                    case "-":
                        {
                            result = num1 - num2;
                            break;
                        }
                    case "*":
                        {
                            result = num2 * num1;
                            break;
                        }
                    case "/":
                        {
                            result = num1 / num2;
                            break;

                        }
                }
                return result;


            });
            return t;
        }
    }
}
