create database employeemanagementdb

create table tbl_employees
(
employeeid int identity(100,5) primary key,
employeename varchar(100),
employeecity varchar(100),
employeesalary varchar(100),
employeedob datetime,
employeedoj datetime,
employeemobileno varchar(100),
employeeemail varchar(100),
employeepassword varchar(100),
employeedept varchar(100)
)
select * from tbl_employees
insert tbl_employees values('chunchu','blr','19000',null,getdate(),'9032483079',
'saiteja@gmail','saiteja1997','teamleader')

create table tbl_employeeavailableleaves
(
employeeid int foreign key references tbl_employees primary key,
sickleave int,
casualleave int,
vacationleave int,
compoff  int
)
select * from tbl_employeeavailableleaves
insert tbl_employeeavailableleaves values(130,10,10,10,5)

create table tbl_employeeleaves
(
leaveid int identity(12345,5) primary key,
employeeid int foreign key references tbl_employees,
leavetype varchar(100),
leaveapplydate datetime,
leavedate datetime,
noofdays int
)
select * from tbl_employeeleaves
insert tbl_employeeleaves values(125,'vacation',getdate(),'12/31/18',5)
create table tbl_employeesalary
(
employeeid int foreign key references tbl_employees,
employeesalary int,
salarymonth int,
salarydate int,
salaryyear int
)
select * from tbl_employeesalary
insert tbl_employeesalary values(125,13000,12,31,2018)




create procedure proc_employeejoinedinthismonth
as
begin
select * from tbl_employees where datename(mm,employeedoj)=datename(mm,getdate())
end
return @@rowcount

exec proc_employeejoinedinthismonth





create procedure proc_employeesalarydetails(@amt int)
as
begin
select * from tbl_employees where employeesalary>@amt 
end

exec proc_employeesalarydetails 20000






create procedure proc_countavgsalary
as
begin
select count(*),sum(employeesalary),avg(employeesalary) from tbl_employees
end
 
 exec proc_countavgsalary






 create procedure proc_join
 as
 begin
 select tbl_employees.employeeid,tbl_employees.employeename,tbl_employeeavailableleaves.casualleave,
 tbl_employeeavailableleaves.sickleave,tbl_employeeavailableleaves.vacationleave,
 tbl_employeeavailableleaves.compoff from tbl_employees join tbl_employeeavailableleaves on
 tbl_employees.employeeid=tbl_employeeavailableleaves.employeeid
 end

 exec proc_join





 create procedure proc_empdetails(@eid int)
 as
 begin
 select tbl_employees.employeeid,tbl_employees.employeename,tbl_employees.employeesalary,
 tbl_employeesalary.employeesalary,tbl_employeesalary.salarymonth,tbl_employeesalary.salarydate
 from tbl_employees join tbl_employeesalary on tbl_employees.employeeid=tbl_employeesalary.employeeid
 where tbl_employees.employeeid=@eid
 end

 exec proc_empdetails 125




 create procedure proc_insert_into2tables(@name varchar(100),@city varchar(100),
 @salary varchar(100),@edob datetime,@edoj datetime,@mob varchar(100),@email varchar(100),
 @pass varchar(100),@dept varchar(100),@sick int,@casual int,@vacation int,@com int)
 as
 begin 
 insert tbl_employees values(@name,@city,@salary,@edob,@edoj,@mob,@email,@pass,@dept)
 insert tbl_employeeavailableleaves values(@@IDENTITY,@sick,@casual,@vacation,@com)
 end

 exec proc_insert_into2tables 'sainath','blr','30000','02-06-1995','11-11-2017','9875461230',
 'sai@gmail','sai1997','hr',10,10,10,5





 create procedure proc_adding_rowinleavestable(@id int,@leavetype varchar(100),@applydate datetime,
 @leavedate datetime,@noofdays int)
 as
 begin
 insert tbl_employeeleaves values(@id,@leavetype,@applydate,@leavedate,@noofdays)
 end
  
  exec proc_adding_rowinleavestable 125,'sick','12-17-2018','01-01-2019',5





create trigger trg_leaves
on tbl_employeeleaves for insert
as 
begin
declare @eid int
declare @leavetype varchar(100)
declare @noofdays int
select @eid=employeeid,@leavetype=leavetype,@noofdays=noofdays from inserted
if(@leavetype='sick')
begin
update tbl_employeeavailableleaves set sickleave=sickleave-@noofdays where employeeid=@eid
end
if(@leavetype='vacation')
begin
update tbl_employeeavailableleaves set vacationleave=vacationleave-@noofdays where employeeid=@eid
end
if(@leavetype='casual')
begin
update tbl_employeeavailableleaves set casualleave=casualleave-@noofdays where employeeid=@eid
end
if(@leavetype='com')
begin
update tbl_employeeavailableleaves set compoff=compoff-@noofdays where employeeid=@eid
end
end

insert tbl_employeeleaves values(130,'sick',getdate(),getdate(),2)





alter trigger trg_salarymont
on tbl_employeesalary for insert
as 
begin
declare @salarymonth int
declare @salaryyear int
declare @salary int
declare @eid int
select @salarymonth=salarymonth,@salaryyear=salaryyear,@salary=employeesalary,@eid=employeeid from inserted
declare @empsalary int
select @empsalary=employeesalary from  tbl_employees where employeeid=@eid
if(datepart(yy,getdate())!= @salaryyear and datepart(mm,getdate())!= @salarymonth and @empsalary<=@salary )
begin
rollback tran
end
end

insert tbl_employeesalary values(130,20000,12,30,18)
select * from tbl_employeesalary

