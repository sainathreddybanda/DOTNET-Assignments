select * from tb1_Customers

alter view v_customer_hyd
with encryption,schemabinding
as
select customerId,CustomerAge,CustomerCity,CustomerName from dbo.tb1_Customers
 where CustomerCity='hyd' with check option

select * from v_customer_hyd

update v_customer_hyd set CustomerCity='pune' where customerId=1098

insert v_customer_hyd values(1013,'sneha','blr',25)



select * from db_bankdb.dbo.accountinfo

sp_helptext v_customer_hyd


create table t1
(
code int,
name varchar(100)
)
select * from t1
insert t1 values(1001,'sai')
insert t1 values(1002,'yash')

create table t2
(
code int,
city varchar(100)
)
select * from t2
insert t2 values(1001,'bgl');
insert t2 values(1002,'hyd');

alter view v_joindata
as
select t1.code,t1.name,t2.city from t1 join t2 on t1.code=t2.code --with check option

select * from v_joindata

insert v_joindata values(1003,'teja','bgl')

create trigger trg_v_joindata
on v_joindata
instead of insert
as
begin
declare @id int
declare @name varchar(100)
declare @city varchar(100)
select @id=code,@name=name,@city=city from inserted
insert t1 values(@id,@name)
insert t2 values(@id,@city)
end



create table tbl_test
(
code int identity(1,1),
name varchar(100),
city varchar(100)
)

declare @count int=0
while @count<100000
begin
insert tbl_test values('sainath','hyd')
set @count=@count+1;
end

select * from tbl_test where code=51000
create clustered index idx
on 
tbl_test(code)


select * from t1;
 create table xyz
 (
 code int,
 name varchar(5)
 )
 begin tran tran1
 begin try
 insert xyz values(15,'hfk')
 insert xyz values(22,'fijd')
 commit tran
 end try
 begin catch
 rollback tran
 end catch

 select * from xyz

 begin tran
 insert xyz values(134,'dgjh')
 select * from xyz

 rollback tran

 commit tran